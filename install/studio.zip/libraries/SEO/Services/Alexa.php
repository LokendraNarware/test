<?php

namespace SEO\Services;

use SEO\Helper\DOM;
use SEO\Common\SEOException;

/**
 * Alexa Scraper
 * Developed by Bailey Herbert
 * https://baileyherbert.com/
 *
 * This class was created for SEO Studio and can be used in compliance with the license you purchased for that product.
 * View CodeCanyon license specifications here: http://codecanyon.net/licenses ("Standard")
 */

class Alexa
{
    private $url;
    private $dom;

    public function __construct($url) {
        new DOM;

        $this->url = $url;

        /*
         * Patch @RC171029
         * Updated the alexa.com link from http:// to https:// protocol.
         * Alexa seems to have added a 301 redirect to https:// which was causing errors. :3
         */
        $ch = curl_init("https://www.alexa.com/siteinfo/{$url->domain}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    	curl_setopt($ch, CURLOPT_ENCODING, "");
    	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; MSIE 9.0; AOL 9.7; AOLBuild 4343.19; Windows NT 6.1; WOW64; Trident/5.0; FunWebProducts)");
    	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "DNT: 1"
        ));
    	$data = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            throw new SEOException("Connect error", 1);
        }

        $this->dom = \SEO\Helper\str_get_html($data);
        if (!is_object($this->dom)) {
            throw new SEOException("Alexa parse failed, try again.", 1);
        }
    }

    public function globalRank() {
        try {
            $rank = $this->dom->find('span.globleRank', 0)->find('strong.metrics-data', 0)->plaintext;
            return (int)str_replace(',', '', $rank);
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function percentBounceRate() {
        try {
            $pct = $this->dom->find('#engage-panel-content', 0)->find('span.span4', 0)->find('strong.metrics-data', 0)->plaintext;
            return (float)str_replace('%', '', $pct);
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function dailyPageviewsPerVisitor() {
        try {
            $views = $this->dom->find('#engage-panel-content', 0)->find('span.span4', 1)->find('strong.metrics-data', 0)->plaintext;
            return (float)$views;
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function dailyTimeOnSite() {
        try {
            $time = $this->dom->find('#engage-panel-content', 0)->find('span.span4', 2)->find('strong.metrics-data', 0)->plaintext;
            return $time;
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function percentTrafficFromSearch() {
        try {
            $a = $this->dom->find('#keywords-panel-content', 0);
            $b = $a->find('span.sitemetrics-col', 0);
            $c = $b->find('strong.metrics-data', 0);
            $d = $c->plaintext;

            return (float)str_replace('%', '', $d);
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function topSearchKeywords() {
        try {
            $results = array();

            $a = $this->dom->find('#keywords-panel-content', 0);
            $b = $a->find('.span-col', 1);
            $c = $b->find('tbody tr');

            foreach ($c as $tr) {
                $phrase = $tr->find('.topkeywordellipsis span', 1);
                if (!$phrase) continue;
                $phrase = $phrase->plaintext;
                $percent = $tr->find('td.text-right span', 0)->plaintext;

                $results[] = array(
                    'keyword' => $phrase,
                    'percent' => (float)str_replace('%', '', $percent)
                );
            }

            return $results;
        }
        catch (Exception $e) {
            return false;
        }
    }

    public function topReferrers() {
        $results = array();

        $a = $this->dom->find('#upstream-content', 0);
        $z = $a->find('.align-center span', 0);
        if ($z && stripos($z->plaintext, "no data")  !== false) {
            return null;
        }

        $b = $a->find('.span-col', 0);
        $c = $b->find('tbody tr');

        foreach ($c as $tr) {
            $domain = $tr->find('td', 0)->plaintext;
            $parts = explode(" ", $domain);
            $domain = $parts[1];
            if (!$domain) continue;

            $percent = $tr->find('td.text-right', 0);
            if ($percent) $percent = $percent->plaintext;
            else $percent = "0%";

            $results[] = array(
                'domain' => $domain,
                'percent' => (float)str_replace('%', '', $percent)
            );
        }

        return $results;
    }

    public function numberBacklinks() {
        try {
            $amount = $this->dom->find('#linksin-panel-content', 0)->find('.font-4', 0)->plaintext;

            return (int)str_replace(',', '', $amount);
        }
        catch (Exception $e) {
            return false;
        }
    }
}
