<?php

namespace SEO\Services;
use \SEO\Common as Common;
use \SEO\Helper as Helper;
use \SEO\Services as Services;
use Exception;

/**
 * Google Scraper
 * Developed by Bailey Herbert
 * https://baileyherbert.com/
 *
 * This class was created for SEO Studio and can be used in compliance with the license you purchased for that product.
 * View CodeCanyon license specifications here: http://codecanyon.net/licenses ("Standard")
 */

class Google
{
    private $url;

    public function __construct($url) {
        $this->url = $url;

        new Helper\DOM;
    }

    /**
     * Performs a Google query and returns an \SEO\Services\GoogleResult object
     * @param String $query The search query to perform
     * @param int    $page  The results page to retrieve (default 1)
     * @param String $html  The HTML code to use, or null to download from Google (default null)
     * @throws \SEO\Common\SEOException when blocked (code 1) or connect error (code 2)
     * @return \SEO\Services\GoogleResult object containing results
     */
    public function query($query, $page = 1, $num = 10, $html = null) {
        global $language;

        $query = urlencode($query);
        $start = (10 * $page) - 10;

        if ($start > 0) $start = "&start=$start";
        else $start = "";

        if ($num > 10) $num = "&num=$num";
        else $num = "";

        $tld = ".com";
        if (isset($language)) $tld = $language->google;

        $ch = curl_init("https://www.google{$tld}/search?q={$query}&gws_rd=ssl{$start}{$num}");
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; MSIE 9.0; AOL 9.7; AOLBuild 4343.19; Windows NT 6.1; WOW64; Trident/5.0; FunWebProducts)");
    	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "DNT: 1"
        ));

        if ($html == null) {
            $data = curl_exec($ch);
            $code = @curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if (curl_errno($ch) > 0) throw new Common\SEOException("CURL error: " . curl_error($ch), 2);
            if ($code != 200) throw new Common\SEOException("Blocked (http $code)", 1);
        }
        else {
            $data = $html;
        }

        # Find the number of results
        # Use preg_replace for multilanguage support

        $dom = Helper\str_get_html($data);
        $results = $dom->find("div[id=resultStats]", 0);

        if (!$results) {
            $number_results = 0;
        }
        else {
            $number_results = (int)preg_replace('/[^0-9]/', '', $results->plaintext);
        }

        # Find the search results

        $results = array();
        $search = $dom->find("div[id=search]", 0);

        if ($search) {
            foreach ($search->find("div[class=g]") as $row) {
                if (!$row->find(".s cite", 0)) continue;
                if (!$row->find(".s .st")) continue;

                $results[] = array(
                    'title' => $row->find("h3 a", 0)->plaintext,
                    'cite' => rtrim(trim($row->find(".s cite", 0)->plaintext), '/\\'),
                    'description' => $row->find(".s .st", 0)->plaintext
                );
            }
        }

        # Try to find the next page link

        $foot = $dom->find("div[id=foot]", 0);
        $nextPage = null;

        if ($foot) {
			$last = null;
			$last1 = $foot->find("td[class=navend] a", -1);
			$last2 = $foot->find("td a[class=fl]", -1);
            if ($last1) {
				if ($last1->find("span", 0)) {
					$last = $last1;
				}
			}
			if ($last2) {
				if ($last2->find("span", 1)) {
					$last = $last2;
				}
			}
			if ($last) {
				$href = $last->href;
				$parts = explode("&", str_replace("&amp;", "&", $href));

				foreach ($parts as $p) {
					if (stripos($p, "start=") !== false) {
						$nextPage = (int)(str_ireplace("start=", "", $p));
						$nextPage = ceil($nextPage / 10) + 1;

						if ($nextPage < $page) $nextPage = null;
					}
				}
			}
        }

        return new GoogleResult($query, (10 * $page) - 10, $number_results, $results, $nextPage);
    }

    /**
    * Gets the indexed pages for the website
    * @param int    $page  The results page to retrieve (default 1)
    * @param int    $num   The number of results to retrieve per page (default is at recommended value of 10)
    * @throws \SEO\Common\SEOException when blocked (code 1) or connect error (code 2)
    * @return \SEO\Services\GoogleResult object containing results
    */
    public function getIndexedPages($page = 1, $num = 10) {
        return $this->query("site:{$this->url->domain}", $page, $num);
    }

    /**
     * Gets the monthly number of searches for a specific query.
     * @param String $query The search query
     * @return array (cpc, vol, value, keyword) or (0, 0, 0, "")
     */
    public static function getSearchVolume($query) {
        $query = strtolower(trim($query));
        $myWords = explode(" ", $query);

        $export = "https://app.serps.com/tools/keywords.json";

        $ch = curl_init($export);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_ENCODING, "identity");
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36");
        curl_setopt($ch, CURLOPT_REFERER, "https://serps.com/tools/keyword-research/");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array(
            'q' => $query
        ));
        $data = @curl_exec($ch);
        if (curl_errno($ch) > 0) return array(0, 0, 0, "");

        $data = @json_decode($data, true);
        if (!$data) return array(0, 0, 0, "");

        foreach ($data['keywords'] as $keyword) {
            $info = $keyword['Tool'];

            $cpc = $info['cpc'];
            $text = $info['text'];
            $vol = $info['vol'];
            $value = $info['value'] / 100;

            $kwWords = explode(" ", $text);
            $match = true;

            if (count($kwWords) != count($myWords)) $match = false;
            foreach ($myWords as $w) if (!in_array($w, $kwWords)) $match = false;

            if ($match) {
                return array($cpc, $vol, $value, $text);
            }
        }

        $max = 0;
        $maxVol = 0;

        foreach ($data['keywords'] as $i => $keyword) {
            $info = $keyword['Tool'];
            $vol = $info['vol'];

            if ($vol > $maxVol) {
                $max = $i;
                $maxVol = $vol;
            }
        }

        if ($maxVol === 0) return array(0, 0, 0, "");

        $info = $data['keywords'][$max]['Tool'];

        $cpc = $info['cpc'] / 100;
        $text = $info['text'];
        $vol = $info['vol'];
        $value = $info['value'] / 100;

        return array($cpc, $vol, $value, $text);
    }
}

class GoogleResult
{
    /**
     * The url-encoded query sent to Google
     */
    public $query;
    /**
     * The start position sent to Google
     */
    public $start;
    /**
     * The number of total results from this search
     */
    public $num_results;
    /**
     * The number of results found on this specific page
     */
    public $num_rows;
    /**
     * The next page number for more results, or NULL if no more pages
     */
    public $next_page;
    private $results;
    private $index;

    public function __construct($query, $start, $num, $rows, $nextPage) {
        $this->query = $query;
        $this->start = $start;
        $this->num_results = $num;
        $this->num_rows = count($rows);
        $this->results = $rows;
        $this->index = 0;
        $this->next_page = $nextPage;
    }

    /**
     * Fetch the next search result array (containing indexes cite, title, and description)
     * @return array of results row or NULL if no more rows
     */
    public function fetch() {
        if (isset($this->results[$this->index]))
            return $this->results[$this->index++];

        return null;
    }
}
