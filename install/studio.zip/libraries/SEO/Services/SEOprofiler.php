<?php

namespace SEO\Services;
use \SEO\Common as Common;
use \SEO\Helper as Helper;
use \SEO\Services as Services;

/**
 * SEO Profiler Scraper & Authenticator
 * Developed by Bailey Herbert
 * https://baileyherbert.com/
 *
 * This class was created for SEO Studio and can be used in compliance with the license you purchased for that product.
 * View CodeCanyon license specifications here: http://codecanyon.net/licenses ("Standard")
 *
 * This class requires registering an email and password at https://seoprofiler.com/
 */

class SEOprofiler
{
    private $email;
    private $password;
    private $loginPage;
    private $projectId;

    public function __construct($email, $password) {
        $this->email = $email;
        $this->password = $password;

        new \SEO\Helper\DOM;
    }

    /**
     * Gets a specific amount of backlinks with the specified sort order
     * @param \SEO\Helper\Url $url  The URL resource for the website
     * @param int             $num  The number of backlinks (max 100)
     * @param int             $sort The sort order (13 = top first, 12 = worst first)
     * @param int             $page The page number to retrieve
     * @throws \SEO\Common\SEOException when not authenticated (code 1), connect error (code 2) or no backlinks (code 3).
     * @return array of statistics, backlinks, and next page number
     */
    public function getBacklinks($url, $num = 100, $sort = 13, $page = 1) {
        if (!$this->projectId) {
            throw new Common\SEOException("Not authenticated", 1);
        }

        $rstart = microtime(true);
        $start = microtime(true);

        $ch = curl_init("https://www.seoprofiler.com/lp/links?q={$url->domain}&pid={$this->projectId}&num={$num}&sort={$sort}&page={$page}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36");
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->getCookieFile());
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->getCookieFile());
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $html = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            throw new Common\SEOException("Failed to connect to seoprofiler.com: curl error: " . curl_error($ch), 1);
        }

        if (stripos($html, "we couldn't find any backlinks") !== false) {
            throw new Common\SEOException("No backlinks found for this website.", 3);
        }

        $dom = Helper\str_get_html($html);
        $stats = $this->getStats($dom);
        $links = $this->getLinks($dom);
        $pages = $this->getPages($dom);

        $dom = null;
        $html = null;

        return array(
            'stats' => $stats,
            'links' => $links,
            'pages' => $pages
        );
    }

    /**
     * Loads cookies and logs in if necessary.
     * @throws \SEO\Common\SEOException for connect error (code 1) or auth error (code 2)
     * @return boolean representing success
     */
    public function authenticate() {
        if ($this->isLoggedIn()) {
            return true;
        }
        else {
            $dom = Helper\str_get_html($this->loginPage);
            $input = $dom->find('input[name=csrfmiddlewaretoken]', 0);

            if (!$input) {
                throw new Common\SEOException("Failed to find form token", 1);
            }

            $post = array(
                'csrfmiddlewaretoken' => $input->value,
                'username' => $this->email,
                'password' => $this->password
            );

            $this->loginPage = null;
            $dom = null;

            $ch = curl_init("https://www.seoprofiler.com/account/login");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36");
            curl_setopt($ch, CURLOPT_COOKIEFILE, $this->getCookieFile());
            curl_setopt($ch, CURLOPT_COOKIEJAR, $this->getCookieFile());
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_exec($ch);

            if (curl_errno($ch) > 0) {
                throw new Common\SEOException("Failed to connect to seoprofiler.com: curl error: " . curl_error($ch), 1);
            }

            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            if ($code == 301 || $code == 302) {
                $url = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
                $parts = explode("-", $url);
                $this->projectId = $parts[count($parts) - 1];

                curl_close($ch);
                return true;
            }

            curl_close($ch);
            throw new Common\SEOException("Failed to authenticate", 2);
        }
    }

    private function getStats($dom) {
        $stats = array();

        $start = microtime(true);

        $container = $dom->find("section[class=content-header] .row", 1);
        if (!$container) return array();

        if (strpos($container->plaintext, 'Sorry, we do not') !== false) {
            throw new Common\SEOException('This site is too big to track backlinks, sorry.', 7);
        }

        $container = $container->find("div[class=col-lg-3 col-md-6 col-sm-6]");
        if (!$container) return array();

        foreach ($container as $stat) {
            $title = trim(strtolower($stat->find("span[class=info-box-text]", 0)->innertext));
            $number = trim(strtolower($stat->find("span[class=info-box-number]", 0)->innertext));

            if ($title == "unique links") {
                $title = "unique active links";

                $num = trim(strtolower($stat->find("span[class=progress-description]", 0)->innertext));
                $stats['active links'] = substr($num, 0, strpos($num, ' '));
            }

            if ($title == "dofollow links") {
                $num = trim(strtolower($stat->find("span[class=progress-description]", 0)->innertext));
                $stats['nofollow links'] = substr($num, 0, strpos($num, ' '));
            }

            $stats[$title] = $number;
        }

        return $stats;
    }

    private function getLinks($dom) {
        $links = array();

        $container = $dom->find(".dataTable", 0);
        if (!$container) return array();

        $container = $container->find("tbody tr");
        if (!$container) return array();

        foreach ($container as $link) {
            $lis = $link->find("td", 0);

            $page = $link->find("td", 1);
            $pageTitle = $page->find("b", 0);
            $pageLink = $page->find("a", 0);

            $anchor = $link->find("td", 2);
            if (!$anchor) continue;
            $anchorText = $anchor->find("b", 0);
            $anchorNoText = $anchor->find("span", 0);
            $anchorLink = $anchor->find("a", 0);

            if (!$anchorText && $anchorNoText != null) {
                $anchorText = $anchorNoText;
            }

            $nofollow = false;
            $noindex = false;

            foreach ($anchor->find("help label smalllabel bg-red tipso_style") as $label) {
                $text = strtolower(trim($label->plaintext));

                if ($text == "nofollow") $nofollow = true;
                if ($text == "noindex") $noindex = true;
            };

            $linkAdded = $link->find("td", 3);

            $data = array();
            if ($lis) $data['influence'] = $lis->find('p', 0)->plaintext;
            if ($pageTitle) $data['page title'] = $pageTitle->plaintext;
            if ($pageLink) $data['page link'] = $pageLink->href;
            if ($anchorText) $data['anchor text'] = $anchorText->plaintext;
            if ($anchorLink) $data['anchor link'] = $anchorLink->href;
            if ($nofollow) $data['nofollow'] = true;
            if ($noindex) $data['noindex'] = true;
            if ($linkAdded) $data['date added'] = str_replace("Link", "", $linkAdded->plaintext);

            $links[] = $data;
        }

        return $links;
    }

    private function getPages($dom) {
        $pages = array(
            'previous' => null,
            'next' => null
        );

        $prevIcon = $dom->find("ul[class=pagination pagination-sm no-margin pull-right] .icon-arrow-left", 0);
        if ($prevIcon) {
            $link = $prevIcon->parent()->href;
            $link = explode("&", $link);
            $pages['previous'] = str_ireplace("page=", "", $link[count($link) - 1]);
        }

        $nextIcon = $dom->find("ul[class=pagination pagination-sm no-margin pull-right] .icon-arrow-right", 0);
        if ($nextIcon) {
            $link = str_replace("&amp;", "&", $nextIcon->parent()->href);
            $link = explode("&", $link);
            $pages['next'] = str_ireplace("page=", "", $link[count($link) - 1]);
        }

        return $pages;
    }

    private function isLoggedIn() {
        $ch = curl_init("https://www.seoprofiler.com/account/login");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36");
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->getCookieFile());
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->getCookieFile());
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $this->loginPage = curl_exec($ch);

        if (curl_errno($ch) > 0) {
            throw new Common\SEOException("Failed to connect to seoprofiler.com: curl error: " . curl_error($ch));
        }

        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($code == 301 || $code == 302) {
            $url = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
            $parts = explode("-", $url);
            $this->projectId = $parts[count($parts) - 1];

            curl_close($ch);
            return true;
        }

        curl_close($ch);
        return false;
    }

    private function getCookieFile() {
        $cookieFileName = md5($this->email);
        $cookieFile = dirname(__FILE__) . "/../Data/$cookieFileName";

        if (!file_exists($cookieFile)) {
            if (file_put_contents($cookieFile, "") === false) {
                throw new Common\SEOException("Failed to create file: " . $cookieFile, 6);
            }
        }

        return realpath($cookieFile);
    }
}
