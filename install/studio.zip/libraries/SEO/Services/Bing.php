<?php

namespace SEO\Services;
use \SEO\Common as Common;
use \SEO\Helper as Helper;
use \SEO\Services as Services;

/**
 * Bing Scraper
 * Developed by Bailey Herbert
 * https://baileyherbert.com/
 *
 * This class was created for SEO Studio and can be used in compliance with the license you purchased for that product.
 * View CodeCanyon license specifications here: http://codecanyon.net/licenses ("Standard")
 */

class Bing
{
    private $url;

    public function __construct($url) {
        new \SEO\Helper\DOM;
        $this->url = $url;
    }

    /**
     * Performs a Bing query and returns an \SEO\Services\BingResult object
     * @param string $query The search query to perform
     * @param int    $page  The first row of results to retrieve (default 0)
     * @throws \SEO\Common\SEOException when blocked (code 1) or connect error (code 2)
     * @return \SEO\Services\BingResult object containing results
     */
    public function query($query, $page = 0) {
        $query = urlencode($query);

        if ($page > 0) $start = "&first=$page";
        else $start = "";

        $ch = curl_init("http://www.bing.com/search?q={$query}{$start}");
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36");
    	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "DNT: 1"
        ));
    	$data = curl_exec($ch);
        $code = @curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch) > 0) throw new Common\SEOException("CURL error: " . curl_error($ch), 2);
        if ($code != 200) throw new Common\SEOException("Blocked (http $code)", 1);

        # Find the number of results
        # Use preg_replace for multilanguage support

        $dom = Helper\str_get_html($data);
        $number_results = 0;
        $results = array();

        if ($dom->find('span.sb_count', 0)) {
            $amount = $dom->find('span.sb_count', 0)->plaintext;
            $number_results = (int)preg_replace('/[^0-9]/', '', $amount);
        }
        $results = $dom->find("div[id=resultStats]", 0);

        # Find the search results

        $search = $dom->find("ol[id=b_results]", 0);

        if ($search) {
            foreach ($search->find("li[class=b_algo]") as $row) {
                if (!$row->find(".b_caption p", 0)) continue;
                $results[] = array(
                    'title' => $row->find("h2 a", 0)->plaintext,
                    'cite' => rtrim(trim($row->find("cite", 0)->plaintext), '/\\'),
                    'description' => $row->find(".b_caption p", 0)->plaintext
                );
            }
        }

        # Try to find the next page link

        $foot = $dom->find("a[class=sb_pagN]", 0);
        $nextPage = null;

        if ($foot) {
            $href = $foot->href;
            $parts = explode("&", str_replace("&amp;", "&", $href));

            foreach ($parts as $p) {
                if (stripos($p, "first=") !== false) {
                    $nextPage = (int)(str_ireplace("first=", "", $p));

                    if ($nextPage < $page) $nextPage = null;
                }
            }
        }

        return new BingResult($query, $page, $number_results, $results, $nextPage);
    }

    /**
    * Gets the indexed pages for the website
    * @param int    $page  The results page to retrieve (default 1)
    * @throws \SEO\Common\SEOException when blocked (code 1) or connect error (code 2)
    * @return \SEO\Services\BingResult object containing results
    */
    public function getIndexedPages($page = 0) {
        return $this->query("site:{$this->url->domain}", $page);
    }
}

class BingResult
{
    /**
     * The url-encoded query sent to Bing
     */
    public $query;
    /**
     * The start position sent to Bing
     */
    public $start;
    /**
     * The number of total results from this search
     */
    public $num_results;
    /**
     * The number of results found on this specific page
     */
    public $num_rows;
    /**
     * The next start row for the next page of results, or NULL if no more pages
     */
    public $next_page;
    private $results;
    private $index;

    public function __construct($query, $start, $num, $rows, $nextPage) {
        $this->query = $query;
        $this->start = $start;
        $this->num_results = $num;
        $this->num_rows = count($rows);
        $this->results = $rows;
        $this->index = 0;
        $this->next_page = $nextPage;
    }

    /**
     * Fetch the next search result array
     * @return array of results row or NULL if no more rows
     */
    public function fetch() {
        if (isset($this->results[$this->index]))
            return $this->results[$this->index++];

        return null;
    }
}
