<?php

namespace SEO\Helper;

/**
 * Converts a URL into a universal object
 */
class Url
{
    public $domain;
    public $scheme;
    public $path;
    public $query;

    public function __construct($url) {
        if (stripos($url, "://") === false)
            $url = "http://" . $url;

        if (filter_var($url, FILTER_VALIDATE_URL) === false)
            throw new \SEO\Common\SEOException("Invalid URL");

        $parse = @parse_url($url);
        if (!isset($parse['host']))
            throw new \SEO\Common\SEOException("Invalid URL");

        if (isset($parse['host'])) $this->domain = strtolower($parse['host']);
        if (isset($parse['scheme'])) $this->scheme = strtolower($parse['scheme']);
        if (isset($parse['path'])) $this->path = $parse['path'];
        if (isset($parse['query'])) $this->query = $parse['query'];
    }
}
