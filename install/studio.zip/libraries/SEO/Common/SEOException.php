<?php

namespace SEO\Common;

class SEOException extends \Exception
{

}
