<?php

namespace Studio\Tools;

class Competition extends Tool
{
    var $name = "Competition";
    var $id = "competition";
    var $icon = "competition";
    var $template = "competition.html";

    var $keyword = "";
    var $you;

    public function prerun($url) {
        global $studio;

        if (isset($_POST['keyword']))
            $this->keyword = $studio->attr(strtolower(trim($_POST['keyword'])));
    }

    public function run() {
        global $studio;

        @ini_set('max_execution_time', 120);

        if ($this->keyword != "") {
            $this->data = array(
                'results' => array(),
                'you' => null
            );

            $google = new \Studio\Ports\Google($this->url);
            $r = $google->query($_POST['keyword']);

            $profiler = new \SEO\Services\SEOprofiler($studio->getopt("seoprofiler-email"), $studio->getopt("seoprofiler-password"));
            $profiler->authenticate();

            while ($row = $r->fetch()) {
                $site = $row['cite'];
                if (stripos($site, "://") === false) $site = "http://$site";

                try {
                    $b = $profiler->getBacklinks(new \SEO\Helper\Url($site));
                    $stats = $b['stats'];
                }
                catch (\Exception $e) {
                    $stats = array(
                        'active links' => "0",
                        'unique active links' => "0",
                        'nofollow links' => "0%",
                        'link influence score' => "0%"
                    );
                }

                $this->data['results'][] = array(
                    'site' => $site,
                    'backlinks' => $stats['active links'],
                    'unique' => $stats['unique active links'],
                    'nofollow' => $stats['nofollow links'],
                    'influence' => $stats['link influence score (lis)']
                );

                $b = null;
            }

            try {
                $b = $profiler->getBacklinks($this->url);
                $stats = $b['stats'];
            }
            catch (\Exception $e) {
                $stats = array(
                    'active links' => "0",
                    'unique active links' => "0",
                    'nofollow links' => "0%",
                    'link influence score' => "0%"
                );
            }

            $this->data['you'] = array(array(
                'site' => "http://" . $this->url->domain,
                'backlinks' => $stats['active links'],
                'unique' => $stats['unique active links'],
                'nofollow' => $stats['nofollow links'],
                'influence' => $stats['link influence score (lis)']
            ));
        }
    }

    public function output() {
        $html = $this->getTemplate();
        $html = str_replace("[[KEYWORD]]", $this->keyword, $html);

        if ($this->keyword == "" || (is_array($this->data) && empty($this->data['results']))) {
            $html = str_replace("[[ITEMS]]", "<tr>
                <td colspan=\"5\">
                    " . rt("Nothing to show.") . "
                </td>
            </tr>", $html);
            $html = str_replace("[[YOU]]", "<tr>
                <td colspan=\"5\">
                    " . rt("Nothing to show.") . "
                </td>
            </tr>", $html);
        }
        else {
            $itemsHTML = "";

            foreach ($this->data['results'] as $i => $c) {
                $rank = $i + 1;
                $odd = (($i % 2 == 0) ? "" : "odd");
                $itemsHTML .= "<tr class=\"$odd\">
                    <td class=\"center\">{$rank}</td>
                    <td>{$c['site']}</td>
                    <td class=\"center\">{$c['influence']}</td>
                    <td class=\"center\">{$c['backlinks']}</td>
                    <td class=\"center\">{$c['unique']}</td>
                    <td class=\"center\">{$c['nofollow']}</td>
                </tr>";
            }

            $html = str_replace("[[ITEMS]]", $itemsHTML, $html);

            $itemsHTML = "";

            foreach ($this->data['you'] as $i => $c) {
                $rank = $i + 1;
                $odd = (($i % 2 == 0) ? "" : "odd");
                $itemsHTML .= "<tr class=\"$odd\">
                    <td class=\"center\">{$rank}</td>
                    <td>{$c['site']}</td>
                    <td class=\"center\">{$c['influence']}</td>
                    <td class=\"center\">{$c['backlinks']}</td>
                    <td class=\"center\">{$c['unique']}</td>
                    <td class=\"center\">{$c['nofollow']}</td>
                </tr>";
            }

            $html = str_replace("[[YOU]]", $itemsHTML, $html);
        }

        echo $html;
    }

    public function record($data = "") {
        if ($this->keyword != "") parent::record("Keyword: " . $this->keyword);
    }

    protected function getCacheKey() {
        return $this->id . ":" . $this->keyword;
    }
}
