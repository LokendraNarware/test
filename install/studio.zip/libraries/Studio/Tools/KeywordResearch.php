<?php

namespace Studio\Tools;

use Exception;

class KeywordResearch extends Tool
{
    var $name = "Keyword Research";
    var $id = "keyword-research";
    var $icon = "keyword-research";
    var $template = "keyword-research.html";

    var $keyword;

    public function prerun($url) {
        $this->keyword = "";
        if (isset($_POST['keyword'])) $this->keyword = $_POST['keyword'];
    }

    public function run() {
        if ($this->keyword != "") {
            $query = strtolower(trim($this->keyword));

            $ch = curl_init("https://dk1ecw0kik.execute-api.us-east-1.amazonaws.com/prod/query?query=" . urlencode($query) . "&language=en&country=us&google=http://www.google.com&service=0");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_ENCODING, "identity");
            curl_setopt($ch, CURLOPT_FAILONERROR, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36");
            $data = @curl_exec($ch);
            if (curl_errno($ch) > 0) return;

            $data = @json_decode($data, true);
            if (json_last_error() != JSON_ERROR_NONE) {
                throw new \Exception('JSON parse failed.');
            }

            if (!isset($data['results']) || !isset($data['results']['processed_keywords'])) {
                throw new \Exception('Keyword data is not in expected format.');
            }

            $keywords = $data['results']['processed_keywords'];
            $items = array();

            function kw_sort($a, $b) {
                if ($a[2] == $b[2]) {
                    return 0;
                }

                return ($a[2] < $b[2]) ? -1 : 1;
            }

            usort($keywords, function($a, $b) {
                if ($a['volume'] == $b['volume']) return 0;
                return $a['volume'] > $b['volume'] ? -1 : 1;
            });

            foreach ($keywords as $k) {
                $items[] = array(
                    'cpc' => $k['cpc'],
                    'text' => $k['keyword'],
                    'vol' => number_format($k['volume']),
                    'comp' => $k['competition']
                );

                if (count($items) > 100) break;
            }

            $this->data = $items;
        }
    }

    public function output() {
        $html = $this->getTemplate();
        $html = str_replace("[[KEYWORD]]", $this->keyword, $html);

        if (is_array($this->data) && count($this->data) > 0) {
            $itemsHTML = "";
            foreach ($this->data as $i => $query) {
                $odd = (($i % 2 == 0) ? "" : "odd");
                $itemsHTML .= "<tr class=\"$odd\">
                    <td>{$query['text']}</td>
                    <td class=\"center\">{$query['cpc']} USD</td>
                    <td class=\"center\">{$query['vol']}</td>
                    <td class=\"center\">{$query['comp']}</td>
                </tr>";
            }
        }
        else {
            $itemsHTML = "<tr>
                <td colspan=\"3\">" . rt("Nothing to show.") . "</td>
            </tr>";
        }

        $html = str_replace("[[ITEMS]]", $itemsHTML, $html);
        echo $html;
    }

    public function record($data = "") {
        if ($this->keyword != "") parent::record("Keyword: " . $this->keyword);
    }

    protected function getCacheKey() {
        return $this->id . ":" . $this->keyword;
    }
}
