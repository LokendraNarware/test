<?php

namespace Studio\Tools;

class GoogleSERP extends Tool
{
    var $name = "Google SERP";
    var $id = "google-serp";
    var $template = "serp.html";
    var $icon = "google-serp";

    var $keyword;

    public function prerun($url) {
        $this->keyword = "";
        if (isset($_POST['keyword'])) $this->keyword = trim(strtolower($_POST['keyword']));
    }

    public function run() {
        // fix for Google class
        new \SEO\Helper\DOM;

        if ($this->keyword !== "") {
            $lookingFor = $this->url->domain;
            $maxPages = 10;
            $numRows = 0;
            $rank = null;
            $sites = array();

            for ($page = 1; $page <= $maxPages; $page++) {
                $google = new \Studio\Ports\Google($this->url);
                $result = $google->query($this->keyword, $page);

                while ($row = $result->fetch()) {
                    $numRows++;
                    $sites[] = $row;

                    if (stripos($row['cite'], $lookingFor) !== false && $rank == null) {
                        $rank = $numRows;
                    }
                }

                if ($rank !== null) break;
                if ($result->next_page === null) break;
            }

            $this->data = array(
                'sites' => $sites,
                'numRows' => $numRows,
                'maxPages' => $maxPages,
                'rank' => $rank
            );
        }
    }

    public function output() {
        $html = $this->getTemplate();

        $html = str_replace("[[TITLE]]", rt("Google Results"), $html);
        $html = str_replace("[[KEYWORD]]", $this->keyword, $html);

        if ($this->data) {
            $rank = $this->data['rank'];

            $a = rt('{$1} was #{$2} in the search results.', $this->url->domain, $rank);
            $b = rt('{$1} did not appear in the first {$2} results.', $this->url->domain, $this->data['numRows']);

            if ($rank !== null) $html = str_replace("[[RANK]]", $a, $html);
            else $html = str_replace("[[RANK]]", $b, $html);

            $itemsHTML = "";
            foreach ($this->data['sites'] as $i => $site) {
                $odd = (($i % 2 == 0) ? "" : "odd");
                $rank = $i + 1;
                $itemsHTML .= "<tr class=\"$odd\">
                    <td class=\"center\">$rank</td>
                    <td class=\"center\">{$site['cite']}</td>
                    <td>{$site['title']}</td>
                </tr>";
            }
        }
        else {
            $html = str_replace("[[RANK]]", rt("Enter a keyword to find your rank."), $html);
            $itemsHTML = "<tr>
                <td colspan=\"3\">" . rt("Nothing to show.") . "</td>
            </tr>";
        }

        $html = str_replace("[[ITEMS]]", $itemsHTML, $html);
        echo $html;
    }

    public function record($data = "") {
        if ($this->keyword != "") parent::record("Keyword: " . $this->keyword);
    }

    protected function getCacheKey() {
        return $this->id . ":" . $this->keyword;
    }
}
