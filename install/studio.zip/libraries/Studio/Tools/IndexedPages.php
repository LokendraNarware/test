<?php

namespace Studio\Tools;

class IndexedPages extends Tool
{
    var $name = "Indexed Pages";
    var $id = "indexed-pages";
    var $icon = "indexed-pages";
    var $template = "indexed-pages.html";

    public function run() {
        $data = array(
            'google' => 0,
            'bing' => 0
        );

        $google = new \Studio\Ports\Google($this->url);
        $gResults = $google->getIndexedPages();

        $bing = new \SEO\Services\Bing($this->url);
        $bResults = $bing->getIndexedPages();

        $data['google'] = $gResults->num_results;
        $data['bing'] = $bResults->num_results;

        $this->data = $data;
    }

    public function output() {
        $html = $this->getTemplate();

        $html = str_replace("[[GOOGLE]]", number_format($this->data['google']), $html);
        $html = str_replace("[[BING]]", number_format($this->data['bing']), $html);

        echo $html;
    }
}
