<?php

namespace Studio\Tools;

class Sitemap extends Tool
{
    var $name = "Sitemap";
    var $id = "sitemap";
    var $icon = "sitemap";
    var $template = "sitemap.html";

    public function run() {
        # First, check robots.txt for a sitemap file.

        $this->data = array(
            'sitemaps' => array(),
            'code' => 0
        );

        $ch = new \Studio\Util\CURL("http://" . $this->url->domain . "/robots.txt");
        $ch->setopt(CURLOPT_RETURNTRANSFER, true);
        $ch->setopt(CURLOPT_FOLLOWLOCATION, true);
        $ch->setopt(CURLOPT_SSL_VERIFYPEER, false);
        $ch->setopt(CURLOPT_SSL_VERIFYHOST, false);
        $ch->setopt(CURLOPT_TIMEOUT, 10);

        try {
            $ch->get();
            $code = $ch->info[CURLINFO_HTTP_CODE];
        }
        catch (\Exception $e) {
            $code = 404;
        }

        if ($code == 200) {
            # We have a working sitemap file. Let's see if it has any sitemaps.

            $s = new \SEO\Parsers\Robots($ch->data);
            $sitemaps = $s->getSitemaps();

            if (count($sitemaps) > 0) {
                foreach ($sitemaps as $arr) {
                    $contents = "";

                    $ch2 = new \Studio\Util\CURL($arr['href']);
                    $ch2->setopt(CURLOPT_RETURNTRANSFER, true);
                    $ch2->setopt(CURLOPT_FOLLOWLOCATION, true);
                    $ch2->setopt(CURLOPT_SSL_VERIFYPEER, false);
                    $ch2->setopt(CURLOPT_SSL_VERIFYHOST, false);
                    $ch2->setopt(CURLOPT_TIMEOUT, 10);

                    try {
                        $ch2->get();
                        $code = $ch2->info[CURLINFO_HTTP_CODE];
                    }
                    catch (\Exception $e) {
                        $code = 404;
                    }

                    $contents = "";
                    $d = 0;
                    if ($code == 200 && substr(strtolower($arr['href']), -4) == ".xml") $contents = $ch2->data;
                    if ($code == 200) $d = 50;

                    $h = str_replace("https://", "http://", ($arr['href']));

                    $this->data['sitemaps'][$h] = array(
                        'xml' => $contents,
                        'code' => $code,
                        'd' => $d
                    );
                }
            }
        }

        # Then, check for the actual sitemap.xml file if it isn't already in the array.

        $ch = new \Studio\Util\CURL("http://" . $this->url->domain . "/sitemap.xml");
        $ch->setopt(CURLOPT_RETURNTRANSFER, true);
        $ch->setopt(CURLOPT_FOLLOWLOCATION, true);
        $ch->setopt(CURLOPT_SSL_VERIFYPEER, false);
        $ch->setopt(CURLOPT_SSL_VERIFYHOST, false);
        $ch->setopt(CURLOPT_TIMEOUT, 10);

        try {
            $ch->get();
            $code = $ch->info[CURLINFO_HTTP_CODE];
        }
        catch (\Exception $e) {
            $code = 404;
        }

        $contents = "";
        $d = 0;
        if ($code == 200) {
            $contents = $ch->data;
            $d = 100;
        }
        $h = str_replace("https://", "http://", $ch->info[CURLINFO_EFFECTIVE_URL]);

        if (isset($this->data['sitemaps'][$h])) {
            $this->data['sitemaps'][$h]['d'] = $d;
        }
        else {
            $this->data['sitemaps'][$h] = array(
                'xml' => $contents,
                'code' => $code,
                'd' => $d
            );
        }
    }

    public function output() {
        global $studio, $page;

        $sitemapsHTML = "";
        $i = 0;
        foreach ($this->data['sitemaps'] as $url => $params) {
            $entries = substr_count(strtolower($params['xml']), "<loc>");
            $i++;

            $domain = parse_url($url);
            $type = "?";
            if ($domain['path']) {
                if (strpos($domain['path'], ".") === false) $type = "?";
                else $type = strtoupper(substr($domain['path'], strpos($domain['path'], ".")+1));
            }

            if ($type != "XML") {
                $entries = "?";
                $params['d'] = ceil($params['d'] * .67);
            }
            if ($params['code'] != 200) $entries = "?";

            $codeimg = "<img src=\"" . $page->getPath() . "resources/images/x32.png\" width=\"16px\" style=\"margin: -2px 3px 0 0;\">";
            if ($params['code'] == 200) $codeimg = "<img src=\"" . $page->getPath() . "resources/images/check32.png\" width=\"16px\" style=\"margin: -2px 3px 0 0;\">";

            $odd = (($i % 2 == 0) ? "odd" : "");

            $sitemapsHTML .= "<tr class=\"$odd\">
                <td>{$url}</td>
                <td class=\"center\">{$codeimg} {$params['code']}</td>
                <td class=\"center\">{$type}</td>
                <td class=\"center\">{$entries}</td>
                <td class=\"center\">{$params['d']}%</td>
            </tr>";
        }

        $html = $this->getTemplate();
        $html = str_replace("[[SITEMAPS]]", $sitemapsHTML, $html);

        echo $html;
    }

    protected function getCacheKey() {
        return "";
    }
}
