<?php

namespace Studio\Tools;

use \SEO\Services\Alexa;
use Exception;

class AlexaRank extends Tool
{
    var $name = "Alexa Rank";
    var $id = "alexa-rank";
    var $icon = "alexa-rank";
    var $template = "stat.html";

    public function run() {
        $alexa = new Alexa($this->url);
        $this->data = $alexa->globalRank();

        if ($this->data == 0) throw new Exception(rt("No rank available yet."));
    }

    public function output() {
        $html = $this->getTemplate();
        $html = str_replace("[[NAME]]", rt("Global Rank"), $html);
        $html = str_replace("[[VALUE]]", $this->data, $html);
        echo $html;
    }
}
