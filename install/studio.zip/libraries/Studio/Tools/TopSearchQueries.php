<?php

namespace Studio\Tools;

use SEO\Services\Alexa;
use SEO\Services\Google;

class TopSearchQueries extends Tool
{
    var $name = "Top Search Queries";
    var $id = "top-search-queries";
    var $icon = "top-search-queries";
    var $template = "search-queries.html";

    public function run() {
        @ini_set('max_execution_time', 120);
        
        $alexa = new Alexa($this->url);
        $topQueries = $alexa->topSearchKeywords();

        foreach ($topQueries as $i => $q) {
            list($cpc, $vol, $value) = Google::getSearchVolume($q['keyword']);
            $topQueries[$i]['cpc'] = number_format($cpc, 2);
            $topQueries[$i]['vol'] = number_format($vol);
            $topQueries[$i]['value'] = number_format($value, 2);
        }

        $this->data = $topQueries;
    }

    public function output() {
        $html = $this->getTemplate();

        $dataHTML = "";
        foreach ($this->data as $i => $query) {
            $odd = (($i % 2 == 0) ? "" : "odd");

            $dataHTML .= "<tr class=\"$odd\">
                <td>{$query['keyword']}</td>
                <td class=\"center\">{$query['percent']}%</td>
                <td class=\"center\">{$query['vol']}</td>
                <td class=\"center\">\${$query['cpc']}</td>
                <td class=\"center\">\${$query['value']} USD</td>
            </tr>";
        }

        if (count($this->data) == 0) {
            $dataHTML = "<tr>
                <td colspan=\"5\">
                    " . rt("Nothing to show.") . "
                </td>
            </tr>";
        }

        $html = str_replace("[[DATA]]", $dataHTML, $html);

        echo $html;
    }
}
