<?php

namespace Studio\Tools;

class KeywordDensity extends Tool
{
    var $name = "Keyword Density";
    var $id = "keyword-density";
    var $template = "keyword-density.html";
    var $icon = "keyword-density";

    var $path;

    public function prerun($url) {
        $this->path = "/";
        if (isset($_POST['path'])) {
            $p = $_POST['path'];
            if ($p == "" || ($p != "" && substr($p, 0, 1) != "/")) $p = "/$p";

            $this->path = $p;
        }
    }

    public function run() {
        if (stripos($this->path, "://") !== false) throw new \Exception("Invalid path");

        $this->data = array(
            'title' => null,
            'description' => null,
            'site' => null,
            'words' => array()
        );

        $ch = new \Studio\Util\CURL("http://" . $this->url->domain . $this->path);
        $ch->setopt(CURLOPT_FOLLOWLOCATION, true);
        $ch->setopt(CURLOPT_SSL_VERIFYHOST, false);
        $ch->setopt(CURLOPT_SSL_VERIFYPEER, false);
        $ch->setopt(CURLOPT_TIMEOUT, 10);
        $ch->get();

        # Get the effective host

        $p = parse_url($ch->info[CURLINFO_EFFECTIVE_URL]);
        $this->data['site'] = $p['scheme'] . "://" . $p['host'];

        # Get all of the page text

        new \SEO\Helper\DOM;

        $dom = \SEO\Helper\str_get_html($ch->data);

        if ($dom === null) {
            throw new Exception(rt('Failed to download webpage: {$1}', 'Got invalid response!'));
        }

        $text = ($dom->find('body', 0)->plaintext);

        # Remove excess whitespace

        $c = 0;
        $text = str_replace("	", " ", $text);
        $text = str_replace("  ", " ", $text, $c);
        while ($c > 0) $text = str_replace("  ", " ", $text, $c);

        $text = html_entity_decode($text);
        $text = strtolower(preg_replace('/[^[:alnum:][:space:]]/', '', $text));

        $allWords = array();

        # One word at a time

        $oneWords = explode(' ', trim($text));
        foreach ($oneWords as $w) {
            if (isset($allWords[$w])) $allWords[$w]++;
            else $allWords[$w] = 1;
        }

        # Two words at a time

        $twoWords = array();
        for ($i = 0; $i < count($oneWords); $i++) {
            if (($i + 1) >= count($oneWords)) break;

            $w = $oneWords[$i] . " " . $oneWords[$i + 1];
            if (isset($allWords[$w])) $allWords[$w]++;
            else $allWords[$w] = 1;
        }

        # Three words at a time

        $threeWords = array();
        for ($i = 0; $i < count($oneWords); $i++) {
            if (($i + 2) >= count($oneWords)) break;

            $w = $oneWords[$i] . " " . $oneWords[$i + 1] . " " . $oneWords[$i + 2];
            if (isset($allWords[$w])) $allWords[$w]++;
            else $allWords[$w] = 1;
        }

        arsort($allWords);

        # Get title and description of page

        $title = $dom->find("title", 0);
        if ($title) $this->data['title'] = $title->innertext;

        $desc = $dom->find("meta[name=description]", 0);
        if ($desc) $this->data['description'] = $desc->content;

        # Cleanup and exit

        $dom = null;
        $this->data['words'] = $allWords;
    }

    public function output() {
        global $page;
        $path = $page->getPath();

        // forgive me...

        $ignoreWords = array(
            "and", "but", "or", "the", "was", "is", "am", "are",
            "were", "be", "been", "this", "that", "these", "those", "who", "whom",
            "whose", "which", "what", "for", "nor", "yet", "an", "a",
            "ours", "our"
        );

        // ok, that's over with. phew.

        $html = $this->getTemplate();
        $html = str_replace("[[SITE]]", $this->data['site'], $html);
        $html = str_replace("[[PATH]]", $this->path, $html);

        if ($this->data['title'] == null) $this->data['title'] = "-";
        if ($this->data['description'] == null) $this->data['description'] = "-";

        $metaHTML = "<tr>
            <td>" . rt("Title") . "</td>
            <td>{$this->data['title']}</td>
        </tr><tr class=\"odd\">
            <td>" . rt("Description") . "</td>
            <td>{$this->data['description']}</td>
        </tr>";

        $i = 0;
        $total = 0;
        foreach ($this->data['words'] as $word => $count) {
            if (strlen($word) < 3) continue;
            if (in_array($word, $ignoreWords)) continue;
            if (substr($word, 0, 1) == "&") continue;

            if ($i > 100) {
                if (stripos($this->data['title'], $word) === false && stripos($this->data['description'], $word) === false) {
                    continue;
                }
            }

            $i++;
            $total += $count;
        }

        $itemsHTML = "";
        $i = 0;
        foreach ($this->data['words'] as $word => $count) {
            if (strlen($word) < 3) continue;
            if (in_array($word, $ignoreWords)) continue;
            if (substr($word, 0, 1) == "&") continue;

            if ($i > 100) {
                if (stripos($this->data['title'], $word) === false && stripos($this->data['description'], $word) === false) {
                    continue;
                }
            }

            $odd = (($i++ % 2 == 0) ? "odd" : "");

            $title = "<img src=\"{$path}resources/images/check32.png\" width=\"16px\" alt=\"Yes\" />";
            if (stripos($this->data['title'], $word) === false) $title = "<img src=\"{$path}resources/images/x32.png\" width=\"16px\" alt=\"No\" />";

            $desc = "<img src=\"{$path}resources/images/check32.png\" width=\"16px\" alt=\"Yes\" />";
            if (stripos($this->data['description'], $word) === false) $desc = "<img src=\"{$path}resources/images/x32.png\" width=\"16px\" alt=\"No\" />";

            $weight = round(100 * ($count / $total), 1);
            $itemsHTML .= "<tr class=\"$odd\">
                <td>$word</td>
                <td class=\"center\">$count</td>
                <td class=\"center\">$title</td>
                <td class=\"center\">$desc</td>
                <td class=\"center\">$weight%</td>
            </tr>";
        }

        $html = str_replace("[[META]]", $metaHTML, $html);
        $html = str_replace("[[ITEMS]]", $itemsHTML, $html);

        echo $html;
    }

    public function record($data = "") {
        parent::record($this->path);
    }

    protected function getCacheKey() {
        return "";
    }
}
