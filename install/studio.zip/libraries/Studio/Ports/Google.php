<?php

namespace Studio\Ports;

use API\SEOHub;
use Exception;

class Google extends \SEO\Services\Google
{
    public function query($query, $page = 1, $num = 10, $html = null) {
        global $studio, $language, $api;

        try {
            return parent::query($query, $page, $num, $html);
        }
        catch (Exception $e) {
            if ($e->getCode() == 1) {
                // we're blocked by Google.
                if ($studio->getopt('google-enabled') == "On") {
                    $tld = ".com";
                    if (isset($language)) $tld = $language->google;

                    if (isset($api)) {
                        $start = (10 * $page) - 10;
                        $google = $api->getGoogleHTML($query, $tld, $num, $start);
                        return parent::query($query, $page, $num, $google);
                    }
                }
            }
            throw new Exception($e->getMessage());
        }
    }
}
