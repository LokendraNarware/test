<?php

namespace Studio\Base;

class Account
{
    private $active;
    private $email;
    private $password;
    private $user;
    private $studio;
    private $site;
    public $groupId;

    public $sessname;

    public function __construct($studio) {
        $this->studio = $studio;
        $this->sessname = $studio->config['session']['token'];

        if (isset($_SESSION[$this->sessname])) {
            $this->email = $_SESSION[$this->sessname]['email'];
            $this->password = $_SESSION[$this->sessname]['password'];

            if ($user = $this->verify()) {
                $this->active = true;
                $this->user = $user;
                $studio->logged_in = true;
                $this->groupId = $user['groupId'];

                $studio->getPluginManager()->call("user_auth", [$user]);
            }
            else {
                $this->logout();
            }
        }

        if (isset($_SESSION['site'])) {
            $this->site = $_SESSION['site'];

            if ($this->active) {
                $time = time();

                if ($p = $studio->sql->prepare("UPDATE websites SET timeAccessed=$time WHERE userId={$user['id']} AND domain=?")) {
                    $p->bind_param("s", $this->site);
                    $p->execute();
                }
            }
        }
    }

    /**
     * Compares the email and password in the session to the actual database session.
     * @return mixed Array of user data on success, or false on failure.
     */
    private function verify() {
        if ($p = $this->studio->sql->prepare("SELECT id, email, password, groupId FROM accounts WHERE email = ? AND password = ?")) {
            $p->bind_param("ss", $this->email, $this->password);
            $p->execute();
            $p->store_result();

            if ($p->num_rows == 1) {
                $p->bind_result($id, $email, $password, $gid);
                $p->fetch();
                $p->close();

                $this->studio->sql->query("UPDATE accounts SET timeLastLogin='".time()."' WHERE id=$id");

                return array(
                    'id' => $id,
                    'email' => $email,
                    'password' => $password,
                    'groupId' => $gid
                );
            }
        }

        return false;
    }

    /**
     * Signs the user out of the current session.
     */
    public function logout() {
        session_destroy();
    }

    /**
     * @return boolean Whether or not the user is logged in.
     */
    public function isLoggedIn() {
        return $this->active;
    }

    /**
     * @return int Current user's ID.
     */
    public function getId() {
        return $this->user['id'];
    }

    /**
     * @return String Current user's email address.
     */
    public function getEmail() {
        return $this->user['email'];
    }

    /**
     * @return String Current user's password (hashed).
     */
     public function getPassword() {
         return $this->user['password'];
     }

     /**
      * @return array Current selected website or NULL if none selected.
      */
     public function getCurrentWebsite() {
         return $this->site;
     }

     /**
      * Sets the selected website or domain name for the user, assuming it has already been validated.
      * @throws \SEO\Common\SEOException when the URL is invalid.
      */
     public function setCurrentWebsite($domain) {
         $url = new \SEO\Helper\Url($domain);

         $_SESSION['site'] = $domain;
         $this->site = $domain;
     }

     /**
      * Authenticates the user using the provided email and password (assuming they have already been validated and are correct)
      */
     public function login($email, $password) {
        $_SESSION[$this->sessname] = array(
            'email' => $email,
            'password' => $password
        );
     }
}
