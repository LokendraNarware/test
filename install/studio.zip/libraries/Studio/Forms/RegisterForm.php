<?php

namespace Studio\Forms;
use Studio\Common\Activity;

class RegisterForm extends Form
{
    private $email;
    private $password;

    public function __construct() {
        $this->errors = array();

        if (isset($_POST['email'])) {
            $this->post();
        }
    }

    public function validate() {
        global $account, $studio;

        $email = strtolower(trim($_POST['email']));
        $password = trim($_POST['password']);
        $confirm = trim($_POST['password2']);

        if ($email == "" || $password == "") {
            $this->errors[] = rt("Please enter an email and password.");
        }

        if ($password !== $confirm) {
            $this->errors[] = rt("Passwords don't match.");
        }

        if (strlen($password) < 6) {
            $this->errors[] = rt("Password must be at least 6 characters.");
        }

        $p = $studio->getPluginManager()->callCombined("register_validate");
        foreach ($p as $fromp) {
            if (is_array($fromp)) {
                foreach ($fromp as $str) {
                    $this->errors[] = $str;
                }
            }
            else {
                $this->errors[] = $fromp;
            }
        }

        if (empty($this->errors)) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL) === false)
                $this->errors[] = rt("Invalid email.");
        }

        if (empty($this->errors)) {
            if ($p = $studio->sql->prepare("SELECT email FROM accounts WHERE email=?")) {
                $p->bind_param("s", $email);
                $p->execute();
                $p->store_result();
                $existing = $p->num_rows;
                $p->close();

                if ($existing == 0) {
                    $this->email = $email;
                    $this->password = $password;

                    return true;
                }
                else $this->errors[] = rt("There is an account with that email, please login.");
            }
            else $this->errors[] = "Database error. #1";
        }

        return false;
    }

    public function post() {
        global $account, $studio;

        if (!$this->validate()) return;
        $time = time();

        if ($p = $studio->sql->prepare("INSERT INTO accounts (email, password, timeLastLogin, timeCreated, groupId) VALUES (?, ?, {$time}, {$time}, 1);")) {
            # Generate a secure blowfish salt and hash the password
            # Note: Blowfish is only supported on PHP 5.3.7+

            $salt = str_replace("+", ".", substr(base64_encode(rand(111111,999999).rand(111111,999999).rand(11111,99999)), 0, 22));
            $salt = '$' . implode('$', array("2y", str_pad(11, 2, "0", STR_PAD_LEFT), $salt));
            $password = @crypt($this->password, $salt);

            if (!$password) $password = @crypt($password);
            if (!$password) $password = md5($password);

            $p->bind_param("ss", $this->email, $password);
            $p->execute();

            if ($studio->sql->affected_rows == 1) {
                $insert_id = $studio->sql->insert_id;

                $p->close();

                $studio->addActivity(new Activity(
                    Activity::INFO,
                    "New account created by user, email " . $this->email . ", from " . $_SERVER['REMOTE_ADDR']
                ));

                $studio->getPluginManager()->call("register_form_new_user", [$insert_id]);

                $account->login($this->email, $password);
                $studio->redirect("account/websites.php");
            }
            else $this->errors[] = "Database error. #3";
        }
        else $this->errors[] = "Database error. #2";
    }

}
