<?php

namespace Studio\Extend;

class PluginManager
{
    private $plugins = array();
    private $hooks = array();

    /**
     * Returns an array of Plugins representing all active plugins.
     * @return array<Plugin> array of all loaded plugins.
     */
    public function getPlugins() {
        return $this->plugins;
    }

    /**
     * Registers and enables a plugin in the system.
     * @param Plugin $plugin The plugin to enable.
     */
    public function registerPlugin($plugin) {
        $this->plugins[] = $plugin;
    }

    public function call($action, $pass = array()) {
        foreach ($this->hooks as $hook) {
            if ($hook['action'] == $action) {
                call_user_func_array(array($hook['plugin'], $hook['run']), $pass);
            }
        }
    }

    public function callCombined($action, $pass = array()) {
        $returns = [];

        foreach ($this->hooks as $hook) {
            if ($hook['action'] == $action) {
                $r = call_user_func_array(array($hook['plugin'], $hook['run']), $pass);
                if ($r != null) $returns[] = $r;
            }
        }

        return $returns;
    }

    public function start() {
        foreach ($this->plugins as $p) {
            $p->start();
        }
    }

    public function newHook($action, $plugin, $name) {
        $this->hooks[] = array(
            'action' => $action,
            'plugin' => $plugin,
            'run' => $name
        );
    }

    public function callMethod($method) {

    }
}
