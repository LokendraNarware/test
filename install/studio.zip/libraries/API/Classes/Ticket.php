<?php

namespace API\Classes;

class Ticket
{
    public $id;
    public $status;
    public $subject;

    private $posts;
    private $i = 0;

    function __construct($data) {
        $this->id = $data->id;
        $this->status = $data->status;
        $this->subject = $data->subject;
        $this->posts = $data->posts;
    }

    function getPost() {
        if (isset($this->posts[$this->i])) return $this->posts[$this->i++];
        return null;
    }
}
