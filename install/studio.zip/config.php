<?php

# SEO Studio
# Configuration File
# Automatically generated

return array(
    "database" => array(
        "host" => "localhost",
        "name" => "seostudio",
        "username" => "root",
        "password" => "",
        "port" => 3306
    ),
    "errors" => array(
        "show" => false,
        "level" => E_ALL
    ),
    "session" => array(
        "token" => "etkjhewkjtheqkjthjkewthk"
    )
);
