<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(11)->setTitle("New Language")->header();

$file = dirname(dirname(__FILE__)) . "/resources/bin/en-us/";
if (!file_exists($file)) die("Not found: $file");

$error = "";

if (isset($_POST['name'])) {
    $name = trim($_POST['name']);
    $locale = $_POST['locale'];
    $dir = $_POST['dir'];
    $google = $_POST['google'];

    if (strlen($name) == 0) {
        $error = "Please enter a the name of the language.";
    }
    if ($error == "") {
        $chkp = $studio->sql->prepare("SELECT * FROM languages WHERE name = ? OR locale = ?");
        $chkp->bind_param("ss", $name, $locale);
        $chkp->execute();
        $chkp->store_result();

        if ($chkp->num_rows !== 0) {
            $error = "A language with that locale or name already exists.";
        }
        else {
            $saveTo = dirname(dirname(__FILE__)) . "/resources/languages/$locale/";
            if (file_exists($saveTo)) {
                $r = rename($saveTo, dirname(dirname(__FILE__)) . "/resources/bin/$locale-old-" . time() . "/");
                if ($r === false) {
                    $error = "Directory already exists: $saveTo. The system failed to automatically remove it. Please rename the directory to something else, like $locale-old.";
                }
            }
        }

        if ($error == "") {
            $b = mkdir($saveTo);
            if ($b === false) {
                $error = "Failed to make directory: $saveTo. Please make it manually and set its mode (chmod) to something PHP can access, like 0777.";
            }
            else {
                $chkp = $studio->sql->prepare("SELECT * FROM languages WHERE name = ? OR locale = ?");
                $chkp->bind_param("ss", $name, $locale);
                $chkp->execute();
                $chkp->store_result();

                if ($chkp->num_rows !== 0) {
                    $error = "A language with that locale or name already exists.";
                }
                else {
                    foreach (scandir($file) as $f) {
                        if (substr($f, 0, 1) == ".") continue;

                        $data = str_replace("\r\n", "\n", file_get_contents($file . $f));
                        $data = trim(str_replace("\n", "", $data));
                        $data = preg_replace('/\s+/', ' ', $data);

                        $items = json_decode($data, true);

                        foreach ($items as $in => $out) {
                            if (!isset($_POST[basename(str_replace(".", "_", $f), '.json') . ':' . md5($in)])) die("Missing field");

                            $items[$in] = $_POST[basename(str_replace(".", "_", $f), '.json') . ':' . md5($in)];
                        }

                        if (defined("JSON_PRETTY_PRINT")) {
                            $new = json_encode($items, JSON_PRETTY_PRINT);
                        }
                        else {
                            $new = json_encode($items);
                        }

                        $bool = file_put_contents($saveTo . $f, $new);
                        if ($bool === false) $studio->showFatalError("Failed to write to $file. Please try making this directory and all files inside have chmod 0777. Contact support for further assistance.");
                    }

                    $p = $studio->sql->prepare("INSERT INTO languages (name, locale, dir, google) VALUES (?, ?, ?, ?)");
                    $p->bind_param("ssss", $name, $locale, $dir, $google);
                    $p->execute();
                    $id = $studio->sql->insert_id;
                    $p->close();

                    header("Location: language.php?id=$id&success=1");
                    die;
                }
            }
        }
    }
}
?>

<?php if ($error != "") { ?>
<div class="error"> <?php echo $error; ?> </div>
<?php } ?>

<form action="" method="post">
    <div class="panel">
        <h3>Language settings</h3>

        <div class="row">
            <div class="col-md-6">
                <div style="margin: 0 0 15px;">
                    <p style="margin: 0 0 2px;">Display Name</p>
                    <input type="text" name="name" class="fancy" value="<?php echo (isset($_POST['name']) ? $studio->attr($_POST['name']) : ''); ?>" style="margin: 0;">
                </div>

                <div style="margin: 0;">
                    <p style="margin: 0 0 2px;">Locale</p>
                    <select name="locale" class="fancy">
                        <?php
                        $locales = trim(file_get_contents(dirname(dirname(__FILE__)) . "/resources/bin/locales"));
                        $locales = explode("\n", $locales);

                        $posted = null;
                        if (isset($_POST['locale'])) $posted = $_POST['locale'];

                        foreach ($locales as $locale) {
                            $locale = trim($locale);
                        ?>
                        <option value="<?php echo $locale; ?>" <?php if ($posted == $locale) echo "selected"; ?>><?php echo $locale; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div style="margin: 0 0 15px;">
                    <p style="margin: 0 0 2px;">Display</p>
                    <select name="dir" class="fancy" style="margin: 0;">
                        <?php
                        $posted = null;
                        if (isset($_POST['dir'])) $posted = $_POST['dir'];
                        ?>
                        <option value="ltr" <?php if ($posted == "ltr") echo "selected"; ?>>Left to right</option>
                        <option value="rtl" <?php if ($posted == "rtl") echo "selected"; ?>>Right to left</option>
                    </select>
                </div>

                <div style="margin: 0;">
                    <p style="margin: 0 0 2px;">Google</p>
                    <select name="google" class="fancy" style="margin: 0;">
                        <?php
                        $googles = trim(file_get_contents(dirname(dirname(__FILE__)) . "/resources/bin/google"));
                        $googles = explode("\n", $googles);

                        $posted = null;
                        if (isset($_POST['google'])) $posted = $_POST['google'];

                        foreach ($googles as $google) {
                            $google = trim($google);
                        ?>
                        <option value="<?php echo $google; ?>" <?php if ($posted == $google) echo "selected"; ?>><?php echo $google; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="panel">
        <p>To edit phrases, click the text on the right side. The text will be selected automatically so you can type to replace it. You can also press TAB to move onto the next translation.</p>
    </div>

    <?php
    foreach (scandir($file) as $f) {
        if (substr($f, 0, 1) == ".") continue;

        $data = str_replace("\r\n", "\n", file_get_contents($file . $f));
        $data = trim(str_replace("\n", "", $data));
        $data = preg_replace('/\s+/', ' ', $data);

        $items = json_decode($data, true);

        echo "<div class=\"panel\"><h3>{$f}</h3>";
        echo "<table class=\"translate\">";

        foreach ($items as $in => $out) {
            $fieldName = basename(str_replace(".", "_", $f), '.json') . ':' . md5($in);
            if (isset($_POST[$fieldName])) $out = $_POST[$fieldName];
    ?>
    <tr>
        <td><?php echo $in; ?></td>
        <td><input type="text" class="select-all" name="<?php echo $fieldName; ?>" value="<?php echo $studio->attr($out); ?>"></td>
    </tr>
    <?php
        }

        echo "</table></div>";
    }
    ?>

    <div class="panel">
        <input type="submit" class="btn blue" value="Create">
    </div>
</form>

<?php
$page->footer();
?>
