<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(19)->setTitle("Header")->header();

if (isset($_POST['sub'])) {
    $image = $_FILES['image'];

    $type = pathinfo(basename($image['name']), PATHINFO_EXTENSION);

    if ($type != "png") die("Invalid extension: $type");
    $b = file_put_contents("../resources/images/logo-old.".time().".png", file_get_contents("../resources/images/logo.png"));
    if ($b === false) die("Cannot write to /resources/images/");

    if(move_uploaded_file($image['tmp_name'], "../resources/images/logo.png")) {
        header("Location: header.php?success");
        die;
    }
    else {
        die("Cannot write to /resources/images/logo.png");
    }
}
?>

<div class="panel" style="background-color: #313d4c;">
    <p><img src="../resources/images/logo.png?t=<?php echo rand() . rand(); ?>" height="45px"></p>
</div>

<div class="panel">
    <h3>Change Logo</h3>
    <p>Upload a .png file to replace the header image. We recommend a horizontal logo with a height of 90px (it will be downsized to 45px).</p>

    <form style="margin: 25px 0 0;" action="" method="post" enctype="multipart/form-data">
        <input type="file" name="image"><br>

        <input type="submit" class="btn green small" name="sub" value="Upload" style="margin: 10px 0 0;">
    </form>
</div>

<div class="panel">
    <h3>Not seeing your new logo?</h3>
    <p>You may need to clear your browser cache before the new logo will appear.</p>
</div>

<?php
$page->footer();
?>
