<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(14)->setTitle("Updates")->header();

if (!isset($_GET['force-check'])) {
    $studio->checkUpdates();
}
else {
    $studio->checkUpdates(0, true);
    header("Location: updates.php");
    die;
}

$q = $studio->sql->query("SELECT * FROM updates WHERE updateStatus = 1 ORDER BY updateTime DESC");
?>

<div class="row">
    <div class="col-md-12">
        <div class="panel">
            <h3>Update history</h3>

            <?php if ($q->num_rows > 0) { ?>
            <div class="table-container thin">
                <table class="table top double">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th class="center" width="170px">Released</th>
                            <th class="center" width="130px">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $statuses = array(
                            0 => 'Ready',
                            1 => 'Installed',
                            2 => 'Failed'
                        );

                        while ($row = $q->fetch_array()) {
                            $status = $statuses[($row['updateStatus'])];
                            $updates[] = $row['token'];
                        ?>
                        <tr data-expand="expand-<?php echo $row['id']; ?>">
                            <td>
                                <?php echo $row['updateName']; ?> &nbsp; <a class="viewmore" style="cursor: pointer;" href="javascript:;">expand</a>

                                <?php if ($status == "Failed") { ?>
                                <div class="error tiny">
                                    <?php echo $row['updateError']; ?>
                                </div>
                                <?php } ?>
                            </td>
                            <td class="center"><?php echo date("j F Y", $row['updateTime']); ?></td>
                            <td class="center"><?php echo $status; ?></td>
                        </tr>
                        <tr id="expand-<?php echo $row['id']; ?>" class="expand hidden">
                            <td colspan="3">
                                <div class="row">
                                    <div class="col-md-6">
                                        <?php echo $row['updateInfo']; ?>

                                        <br><br>

                                        <div style="margin: 0 0 6px;">
                                            <strong>Version: </strong> <?php echo $row['updateVersion']; ?>
                                        </div>
                                        <div style="margin: 0 0 6px;">
                                            <strong>Type: </strong> <?php echo $row['updateType']; ?>
                                        </div>
                                        <div style="margin: 0;">
                                            <strong>Token: </strong> <?php echo $row['token']; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <strong style="display: block; margin: 0 0 7px;">This update modified these files:</strong>
                                        <ul><?php
                                        $files = unserialize($row['updateFiles']);
                                        foreach ($files as $f) echo "<li>$f</li>";
                                        ?></ul>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php
                        }

                        if ($q->num_rows == 0) {
                        ?>
                        <tr>
                            <td colspan="3">No updates at this time.</td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <?php } else { ?>
            <div class="no-updates">
                <div class="pull-left"><i class="material-icons">done</i></div>
                <div class="pull-left text">You're running the latest version.</div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<script>
$(".viewmore").click(function() {
    var tr = $(this).parent().parent();
    var expandid = tr.attr("data-expand");

    $(".expand").each(function() {
        if ($(this).attr("id") != expandid) {
            $(this).addClass("hidden");
        }
    });

    $("#"+expandid).toggleClass("hidden");
});
</script>

<?php
$page->footer();
?>
