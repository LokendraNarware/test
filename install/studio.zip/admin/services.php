<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(22)->setTitle("Services")->header();
?>

<div class="panel v2">
    <h2>
        <i class="material-icons">&#xE2BD;</i>
        Services
    </h2>

    <?php if ($studio->getopt('cron-last-run') < (time() - 43200)) { ?>
        <div class="warning v2">
            <div class="icon">
                <i class="material-icons">&#xE002;</i>
            </div>

            <p>Your cron job hasn't run yet. If you haven't installed it, click "Cron Job" below to install it instantly. Otherwise, ignore this message.</p>
        </div>
    <?php } ?>

    <div class="menu v2">
        <ul>
            <li>
                <a href="google.php">
                    <i class="material-icons">&#xE8B6;</i>
                    <strong>Google</strong>
                    <p>Configure free search proxying from the cloud.</p>
                </a>
            </li>
            <li>
                <a href="cron.php">
                    <i class="material-icons">&#xE86A;</i>
                    <strong>Cron Job</strong>
                    <p>View the cron job status or instantly install it.</p>
                </a>
            </li>
        </ul>
    </div>
</div>


<?php
$page->footer();
?>
