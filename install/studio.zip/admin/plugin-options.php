<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(5)->setTitle("Plugins")->header();

$baseDir = dirname(dirname(__FILE__));
$pluginsDir = $baseDir . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "plugins";

$id = $_GET['id'];
if (!is_numeric($id)) die;

$q = $studio->sql->query("SELECT * FROM plugins WHERE id = $id");
if ($q->num_rows == 0) die;

$row = $q->fetch_object();
$dir = $row->directory;


$className = $dir;
require_once "$pluginsDir/$dir/$className.php";
$o = new $className;
$o->pluginDir = "$pluginsDir/$dir";
$o->settings();

$page->footer();
?>
