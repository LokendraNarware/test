<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(22)->setTitle("Google")->header();

if (!$api->isAuthorized()) {
    require "_locked.php";
    $page->footer();
    $studio->stop();
}

if ($studio->getopt("google-enabled") != "On") {
    if (isset($_POST['email'])) {
        try {
            $ok = $api->enableGoogle($_POST['url'], $_POST['email']);
            if ($ok) {
                $studio->setopt("google-enabled", "On");
                header("Location: google.php?success=1");
                die;
            }
            echo "<div class='error'>We couldn't sign you up for the network right now.</div>";
        }
        catch (Exception $e) {
            echo "<div class='error'>{$e->getMessage()}</div>";
        }
    }
?>

<div class="panel">
    <h3>Google Network</h3>
    <p>The Google Network is the easiest way to automatically configure proxying when Google blocks your IP address.</p>
</div>

<div class="panel">
    <h3>Join the network</h3>
    <p>You must read the following information and terms before joining the network.</p>

    <iframe style="width: 100%; height: 600px; border-left: 2px solid #ddd; margin: 25px 0; border-top: 1px solid #eee;" src="../resources/eulas/google.html"></iframe>

    <p>By joining this network, you signify understanding and acceptance of the above terms. Please enter a valid email address where we can contact you if we make changes to the terms above.</p>

    <form action="" method="post">
        <input type="hidden" name="url" value="">
        <input type="text" name="email" class="fancy" placeholder="Email..." style="margin: 15px 0 5px;">

        <input type="submit" class="btn blue" value="Join Network">
    </form>
</div>

<script type="text/javascript">
    var url = window.location.href;
    $("input[name=url]").val(url.substring(0, url.indexOf("/admin") + 1));
</script>

<?php
}
else {

    if (isset($_GET['disable'])) {
        try {
            $ok = $api->disableGoogle();
            if ($ok) {
                $studio->setopt("google-enabled", "Off");
                header("Location: google.php?success=1");
                die;
            }
            echo "<div class='error'>We couldn't disable your network membership right now. Try contacting support.</div>";
        }
        catch (Exception $e) {
            echo "<div class='error'>{$e->getMessage()}</div>";
        }
    }
?>

<div class="panel">
    <h3>Google Network</h3>
    <p>You're currently participating in the Google Network. SEO Studio will automatically switch to this network if Google blocks your IP.</p>

    <a class="btn" href="?disable" style="margin: 15px 0 0;">Disable</a>
</div>

<?php
}
$page->footer();
?>
