<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(13)->setTitle("Market")->header();

if (isset($_GET['go'])) {
    $studio->setopt("market-count", 0);
    header("Location: https://getseostudio.com/plugins?login=" . urlencode($studio->getopt("api.secretkey")));
    die;
}
?>

<div class="panel bigicon">
    <i class="material-icons">shopping_basket</i>
    <h3>Get more tools and features with plugins</h3>

    <a class="btn medium" href="?go" target="_blank">Browse plugins</a>
</div>

<?php
$page->footer();
?>
