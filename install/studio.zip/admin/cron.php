<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(22)->setTitle("Cron Job")->header();

if (isset($_POST['doJoinCronService'])) {
    $url = $_POST['url'];

    try {
        $data = $api->enableCron($url);
        if ($data->enabled) {
            $studio->setopt('cron-token', $data->token);

            header("Location: cron.php?success=1&ce=1");
            die;
        }

        echo "<div class='error'>Couldn't enable the cron service.</div>";
    }
    catch (Exception $e) {
        echo "<div class='error'>{$e->getMessage()}</div>";
    }
}

if (isset($_GET['stopcron'])) {
    try {
        $data = $api->disableCron();
        if ($data->disabled) {
            $studio->setopt('cron-token', '');

            header("Location: cron.php?success=1");
            die;
        }

        echo "<div class='error'>Couldn't disable the cron service right now. You can try contacting customer support.</div>";
    }
    catch (Exception $e) {
        echo "<div class='error'>{$e->getMessage()}</div>";
    }
}

?>

<?php
if ($studio->getopt('cron-last-run') < (time() - 43200)) {
    if ($studio->getopt('cron-token') != '') {
?>
<div class="panel waittime">
    <div class="icon"><i class="material-icons">access_time</i></div>
    <h3>The cron service is getting ready.</h3>
    <p>Please allow a few minutes for our servers to run your cron job remotely.</p>
</div>
<?php
    }
?>

<div class="panel">
    <h3>Please configure the cron job</h3>
    <p>In order for the system to function properly, the cron job must be configured to automatically run multiple times per day. You have three options, shown below.</p>
</div>

<div class="panel">
    <h3>Configure the cron job on your server</h3>
    <p>Ask your web host for help with configuring the following cron job:</p>

    <?php
    $pathToCron = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "execute" . DIRECTORY_SEPARATOR . "cron.php";
    ?>
    <pre style="border-left: 3px solid #e6e6e6; background: #f3f3f3; margin: 20px 0 0; padding: 13px 20px;">0,30 * * * * php -q <?php echo $pathToCron; ?></pre>

    <hr class="big">

    <h3>Activate the free cron service</h3>
    <p style="margin: 0 0 15px;">Registered copies of SEO Studio that are hosted on publicly-accessible websites can have the cron job automatically set up by this service to run every few hours.</p>

    <?php
        if (!$api->isAuthorized()) {
    ?>
        <p>You're not eligible for the cron service because you haven't activated SEO Studio.</p>
        <a class="btn green envatoSigninButton" href="javascript:;" style="margin: 8px 0 0;">Activate</a>
        <a class="btn" href="<?php echo $api->getPurchaseURL(); ?>" target="_blank" style="margin: 8px 0 0;">Buy another license</a>
    <?php
    }
    else {
    ?>
    <form action="" method="post">
        <input type="hidden" name="url">
        <?php if ($studio->getopt('cron-token') != '') echo "<em>Cron service is running</em>"; else { ?>
            <input type="submit" name="doJoinCronService" value="Activate" class="btn blue">
        <?php } ?>
    </form>
    <?php
    }
    ?>

    <hr class="big">

    <h3>Run the cron manually (not recommended)</h3>
    <p>You can run the cron manually by clicking the button below, at least once per day is recommended.</p>

    <a class="btn runCron" style="margin: 10px 0 0;">Run cron</a>
</div>

<div class="modal-bg run-modal">
    <div class="modal">
        <div class="t">
            Running cron
        </div>
        <div class="b center">
            <div style="padding: 0 0 30px;">
                <img src="../resources/images/load32.gif" width="16px">
            </div>
            <div class="progressbar">
                <div class="progress"></div>
            </div>
            <div class="status">
                Executing cron job
            </div>
        </div>
    </div>
</div>
<?php
}
else {
?>
<div class="panel">
    <h3>Cron is configured and working!</h3>
    <p>Congratulations on successfully configuring your cron job. It last ran <?php
     echo (new \Studio\Display\TimeAgo($studio->getopt('cron-last-run')))->get(); ?>.</p>
</div>
<?php
if ($studio->getopt("cron-token") != "") {
?>
<div class="panel">
    <h3>Cron service</h3>
    <p>Our servers are periodically running your cron job remotely. If you've moved to a new URL, click the button below to update it.</p>

    <form action="" method="post" style="margin: 15px 0 0;">
        <input type="hidden" name="url">

        <input class="btn green" type="submit" name="doJoinCronService" style="margin: 8px 0 0;" value="Update URL">
        <a class="btn" href="?stopcron">Disable</a>
    </form>
</div>
<?php
}
}
?>

<script type="text/javascript">
    var url = window.location.href;
    $("input[name=url]").val(url.substring(0, url.indexOf("/admin")+1));

    $(".runCron").click(function() {
        $(".run-modal").show();
        $(".run-modal .progress").animate({ width: '100%' }, 20000, 'linear');

        $.get("exec_cron.php", function(data) {
            if (data.indexOf("successful") === -1) {
                alert("Cron job failed to run! Unknown response! Contact support.");
            }
            else {
                $(".run-modal .progress").stop().animate({ width: '100%' }, 600, 'linear');
                setTimeout(function() {
                    window.location.href = "cron.php?success";
                }, 1000);
            }
        }).fail(function() {
            alert("Cron job failed to run! HTTP error.");
        });
    });
</script>

<?php
$page->footer();
?>
