<?php

require "includes/init.php";

$page->requirePermission('admin-access');
$id = $_POST['id'];

if (stripos($id, ".") !== false) die;

$file = "diag/$id.php";
if (!file_exists($file)) {
    die(json_encode([
        'test' => $id,
        'success' => false,
        'message' => 'Failed to run diagnosis.'
    ]));
}

require $file;
$o = new $id($studio->sql);

?>
