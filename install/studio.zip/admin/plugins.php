<?php
header("Location: settings/extensions.php");
