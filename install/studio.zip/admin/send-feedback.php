<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(0)->setTitle("Send Feedback")->header();

if (isset($_POST['message'])) {
    $message = trim($_POST['message']);

    if (strlen($message) == 0) {
        die('Enter a message. <a href="">OK</a>');
    }

    try {
        $api->sendFeedback($message);

?>

        <div class="panel v2">
            <h2>
                <i class="material-icons">&#xE87F;</i>
                Feedback sent!
            </h2>

            <p style="max-width: 700px; margin: 0 0 45px;">
                We've received your message, and will review it soon. We will not email you about your feedback, and it is not guaranteed to be considered, however we will keep it in mind!
            </p>

            <p style="max-width: 700px; margin: 0 0 15px;">By the way, did you know you can get email notifications when new updates are out?</p>
            <a class="subscribe" target="_blank" href="http://eepurl.com/c-Aqq1">Email me updates</a>
        </div>


<?php
    }
    catch (Exception $e) {
        echo "<div class='error'>{$e->getMessage()}</div>";
    }
}
else {
    ?>


    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE87F;</i>
            Send feedback
        </h2>

        <p style="max-width: 700px; margin: 0 0 15px;">
            For general feedback and feature requests, please enter your comments below. We review these regularly.
            Don't use this page for support. If you need immediate assistance, <a href="support.php">contact us
                directly</a>.
        </p>

        <div class="feedback">
            <form action="" method="post">
                <p>Enter your comments.</p>
                <textarea name="message"></textarea>
                <input type="submit" value="Send">
            </form>
        </div>
    </div>


    <?php
}
$page->footer();
?>
