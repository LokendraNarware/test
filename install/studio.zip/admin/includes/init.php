<?php

error_reporting(E_ALL);
ini_set('display_errors', 'On');

ob_start();
session_start();

date_default_timezone_set("America/Phoenix");

require_once dirname(dirname(dirname(__FILE__))) . "/libraries/autoload.php";

$studio = new \Studio\Base\Studio();
$plugins = $studio->getPluginManager();
$account = new \Studio\Base\Account($studio);
$page = new \Studio\Display\AdminPage($studio);
$api = new \API\API($studio->getopt("api.secretkey"));

if ($studio->getopt('update-missing-translations') == "1" && !isset($noTranslationRedir)) {
    header("Location: update-translations.php");
    die;
}

# Call the studio_loaded plugin hook

$plugins->start();
$plugins->call("studio_loaded");

$update_count = 0;

# Find the number of available updates

$q = $studio->sql->query("SELECT COUNT(*) FROM updates WHERE updateStatus != 1");
$r = $q->fetch_array();
$update_count += $r[0];

$q = $studio->sql->query("SELECT COUNT(*) FROM plugins WHERE update_available != ''");
$r = $q->fetch_array();
$update_count += $r[0];

?>
