<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(16)->setTitle("Live Support Chat")->header();
?>

<audio id="notification">
    <source src="../resources/sounds/notification.mp3" type="audio/mpeg">
    <source src="../resources/sounds/notification.ogg" type="audio/ogg">
    <source src="../resources/sounds/notification.wav" type="audio/wav">
</audio>

<div class="panel chat">
    <div class="status">
        <h3 class="chatname">Loading</h3>

        <div class="chatbox">
            <div class="log">
                <div class="loading">
                    <img src="../resources/images/load32.gif" width="16px" style="margin-top: -4px;"> &nbsp; Connecting...</p>
                </div>
            </div>
            <div class="input">
                <textarea placeholder="Type your message..."></textarea>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function playSound() {
        $("#notification")[0].play();
    }

    var messages = [];
    var requests = [];
    var currentRequest;
    var sessionID = "";
    var token = "<?php echo $studio->getopt('token'); ?>";

    var lastMessageBy = "";
    var color = "white";

    $(function() {
        $.post("https://baileyherbert.com/api/seostudio/support/live/connect", { token: token }, function(data) {
            sessionID = data.sessionId;

            $.post("https://baileyherbert.com/api/seostudio/support/live/chatlog", { session: sessionID }, function(data) {
                $(".log").html("");
                $(".chatname").html("Waiting for agent");

                updateChatLog(data.chat);
                updateRequests(data.requests);
                setTimeout(downloadChatLog, 2500);
            }, 'json').fail(function() {
                $(".log .loading").html("Failed to download chat, please use the ticket system instead.");
            });
        }, 'json').fail(function() {
            $(".log .loading").html("Failed to authenticate chat, please use the ticket system instead.");
        });

        $(".chatbox .input textarea").keydown(function(e) {
            if (e.keyCode == 13) {
                submitMessage();
                return false;
            }
        });

        $(".chatbox .input textarea").focus();

        $(".modal .approveButton").click(function() {
            if ($(this).hasClass("disabled")) return;
            $(this).addClass("disabled");
            $(this).parent().find(".declineButton").addClass("disabled");

            if (currentRequest == "url") {
                var location = window.location.href;
                $.post("https://baileyherbert.com/api/seostudio/support/live/request", { session: sessionID, request: currentRequest, response: location }, function(data) {
                    $(".modal-bg").hide().find(".disabled").removeClass("disabled");
                }, 'json');
            }
            if (currentRequest == "admin-access") {
                var r = window.location.href + " with key <?php echo md5(file_get_contents('../config.php') . $studio->getopt('token')); ?>";
                $.post("https://baileyherbert.com/api/seostudio/support/live/request", { session: sessionID, request: currentRequest, response: r }, function(data) {
                    $(".modal-bg").hide().find(".disabled").removeClass("disabled");
                }, 'json');
            }
            if (currentRequest == "phpinfo") {
                $.get("../resources/bin/phpinfo.php?token=" + token, function(r) {
                    $.post("https://baileyherbert.com/api/seostudio/support/live/request", { session: sessionID, request: currentRequest, response: r }, function(data) {
                        $(".modal-bg").hide().find(".disabled").removeClass("disabled");
                    }, 'json');
                }).fail(function() {
                    alert("Failed!");
                    $(".modal-bg").hide().find(".disabled").removeClass("disabled");
                });

            }
        });

        $(".modal .declineButton").click(function() {
            if ($(this).hasClass("disabled")) return;
            $(this).addClass("disabled");
            $(this).parent().find(".approveButton").addClass("disabled");

            $.post("https://baileyherbert.com/api/seostudio/support/live/request", { session: sessionID, request: currentRequest, decline: "1" }, function(data) {
                $(".modal-bg").hide().find(".disabled").removeClass("disabled");
            }, 'json');
        });
    });

    function submitMessage() {
        var message = $(".chatbox .input textarea").val();
        $(".chatbox .input textarea").val("");

        $.post("https://baileyherbert.com/api/seostudio/support/live/send", { session: sessionID, message: message }, function(data) {
            updateChatLog(data.chat);
            updateRequests(data.requests);
        }, 'json').fail(function() {
            $(".chatbox .input textarea").val(message).focus();
        });
    }

    function updateChatLog(data) {
        var newMessages = false;

        $.each(data, function(i, item) {
            if (messages.indexOf(item.id) === -1) {
                if (!item.me) newMessages = true;

                if (lastMessageBy == item.name) {
                    // the last message was by the same person.
                    // let's add it to the existing div.

                    $(".log div").last().append("<p>" + item.message + "</p>");
                }
                else {
                    // the last message was by someone else
                    // make a new div

                    if (color == "white") color = "gray";
                    else color = "white";

                    lastMessageBy = item.name;
                    var me = (item.me) ? "blue" : "";

                    $(".log").append("<div class=\"chat-item " + color + "\"><strong class=\""+me+"\">" + item.name + "</strong><p>" + item.message + "</p></div>");

                    if (item.name != "System" && !item.me) {
                        $(".chatname").removeClass("gray").html("Chatting with " + item.name);
                    }
                }

                messages.push(item.id);
                $(".log").scrollTop($('.log')[0].scrollHeight);
            }
        });

        if (newMessages) {
            playSound();
        }
    }

    function updateRequests(r) {
        $.each(r, function(i, request) {
            if (requests.indexOf(request.id) === -1) {
                requests.push(request.id);
                if (request.request == "url") $(".modal .b").html("The support technician is requesting the URL to your SEO Studio installation. Click Approve to automatically send the URL.");
                if (request.request == "admin-access") $(".modal .b").html("The support technician is requesting temporary access to your admin panel. This will NOT allow them to see your password or make changes to files.");
                if (request.request == "phpinfo") $(".modal .b").html("The support technician is requesting that details on your PHP version and configuration be sent to them.");

                $(".modal-bg").show();

                currentRequest = request.request;
            }
        });
    }

    function downloadChatLog() {
        $.post("https://baileyherbert.com/api/seostudio/support/live/chatlog", { session: sessionID }, function(data) {
            updateChatLog(data.chat);
            updateRequests(data.requests);
            setTimeout(downloadChatLog, 2500);
        }, 'json').fail(function() {
            setTimeout(downloadChatLog, 3500);
        });
    }
    function downloadChatLogOnce() {
        $.post("https://baileyherbert.com/api/seostudio/support/live/chatlog", { session: sessionID }, function(data) {
            updateChatLog(data);
        }, 'json');
    }
</script>

<div class="modal-bg">
    <div class="modal">
        <div class="t">
            Authorize action
        </div>
        <div class="b">
            The support technician is requesting temporary access to your admin panel. This will NOT allow them to see your password or make changes to files.
        </div>
        <div class="c">
            <a class="btn green approveButton">Approve</a>
            <a class="btn red declineButton">Decline</a>
        </div>
    </div>
</div>

<?php
$page->footer();
?>
