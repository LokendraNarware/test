<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(16)->setTitle("Customer Support")->header();

if (!$api->isAuthorized()) {
    require "_locked.php";
    $page->footer();
    $studio->stop();
}

try {
    $ticket = $api->getTicket($_GET['id']);
}
catch (Exception $e) {
    echo "<div class='error'>{$e->getMessage()}</div>";
    $page->footer();
    $studio->stop();
}

if (isset($_POST['message'])) {
    try {
        $ticket = $api->createTicketResponse($_GET['id'], $_POST['message']);
        header("Location: ticket.php?id=" . $_GET['id']);
        die;
    }
    catch (Exception $e) {
        echo "<div class='error'>{$e->getMessage()}</div>";
        $page->footer();
        $studio->stop();
    }
}

?>

<div class="panel">
    <div class="pull-right">
        <a class="btn" href="support.php" style="margin-top: -5px;">Back to tickets</a>
        <a class="btn blue" onclick="$('.reply-form').removeClass('hidden');">Reply</a>
    </div>
    <h3 style="margin: 2px 0 0;"><?php echo $ticket->subject; ?></h3>

    <form action="" class="reply-form hidden" method="post" style="margin: 20px 0 0;">
        <textarea name="message" placeholder="Enter a reply here..." class="fancy" rows="5" style="margin-bottom: 15px;"><?php if (isset($_POST['message'])) echo $_POST['message']; ?></textarea>
        <input type="submit" class="btn blue" value="Reply">
    </form>
</div>

<?php
if ($ticket->status == "active") {
?>
<div class="panel waittime">
    <div class="icon"><i class="material-icons">access_time</i></div>
    <h3>We're working on getting to your ticket.</h3>
    <p>Our support team is active 9AM &ndash; 6PM MST.</strong></p>
</div>
<?php
}

while ($message = $ticket->getPost()) {
?>
<div class="panel message<?php if ($message['is_staff'] == "1") echo ' agent'; ?>">
    <div class="pull-right">
        <div class="time right">
            <?php echo (new \Studio\Display\TimeAgo($message['created_at']))->get(); ?>
        </div>
    </div>
    <h3><?php
    if (!$message['is_staff']) echo "<strong>You</strong>";
    else echo "<strong>" . $message['created_by'] . "</strong>";
    ?> said:</h3>

    <div class="text">
        <?php echo $message['body']; ?>
    </div>
</div>
<?php
}

$page->footer();
?>
