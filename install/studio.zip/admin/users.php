<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(9)->setTitle("Users")->header();

# Get total number of rows

$q = $studio->sql->query("SELECT COUNT(*) FROM accounts");
$r = $q->fetch_array();
$total = $r[0];

# Pagination

$curPage = ((isset($_GET['page']) && is_numeric($_GET['page'])) ? (int)$_GET['page'] : 1);
$pagination = new Studio\Display\Pagination($curPage, 15, $total);
$p = $pagination->getQuery();

# Sorting

$sort = "id ASC";

$q = $studio->sql->query("SELECT * FROM accounts ORDER BY $sort $p");
$groups = array();
?>

<div class="panel">
    <div class="pull-right">
        <a class="btn small blue" href="new-user.php" style="vertical-align: top; margin-top: -5px;">Add a user</a>

        <?php
        $pagination->show("right tmfix inline");
        ?>
    </div>

    <h3><?php echo $total; ?> users</h3>

    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th width="60px" class="center">Id</th>
                    <th>Email</th>
                    <th>Group</th>
                    <th width="150px" class="right">Last Online</th>
                    <th width="150px" class="right">Date Created</th>
                    <th width="250px">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $q->fetch_array()) {
                ?>
                <tr>
                    <td class="center"><?php echo $row['id']; ?></td>
                    <td><a href="user.php?id=<?php echo $row['id']; ?>"><?php echo $row['email']; ?></a></td>
                    <td><?php

                    $id = $row['groupId'];
                    echo "<a href=\"group.php?id=$id\">";
                    if (isset($groups[$id])) echo $groups[$id];
                    else {
                        $o = $studio->sql->query("SELECT * FROM groups WHERE id='$id'");

                        if ($o->num_rows == 0) echo "No group";
                        else {
                            $r = $o->fetch_array();
                            $groups[$id] = $r['name'];
                            echo $r['name'];
                        }
                    }
                    echo "</a>";

                    ?></td>
                    <td>
                        <div class="time right">
                            <?php echo (new \Studio\Display\TimeAgo($row['timeLastLogin']))->get(); ?>
                            <span data-time="<?php echo $row['timeLastLogin']; ?>"><i class="material-icons">access_time</i></span>
                        </div>
                    </td>
                    <td>
                        <div class="time right">
                            <?php echo (new \Studio\Display\TimeAgo($row['timeCreated']))->get(); ?>
                            <span data-time="<?php echo $row['timeCreated']; ?>"><i class="material-icons">access_time</i></span>
                        </div>
                    </td>
                    <td class="right">
                        <a class="btn tiny" href="user.php?id=<?php echo $row['id']; ?>">Manage</a>
                        <a class="btn tiny red" href="user.php?id=<?php echo $row['id']; ?>&delete">Delete</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php
    $pagination->show("right no-margin-bottom");
    ?>
</div>

<?php
$page->footer();
?>
