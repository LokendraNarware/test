<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(3)->setTitle("Settings")->header();
?>

<div class="panel v2">
    <h2>
        <i class="material-icons">&#xE8B8;</i>
        Settings
    </h2>

    <div class="menu v2">
        <ul>
            <li>
                <a href="settings/general.php">
                    <i class="material-icons">&#xE873;</i>
                    <strong>Configuration</strong>
                    <p>General application settings such as errors and updates.</p>
                </a>
            </li>
            <li>
                <a href="settings/accounts.php">
                    <i class="material-icons">&#xE7FD;</i>
                    <strong>Accounts</strong>
                    <p>Basic settings for your website's users and public portal.</p>
                </a>
            </li>
            <li>
                <a href="settings/ads.php">
                    <i class="material-icons">&#xE3F4;</i>
                    <strong>Advertising</strong>
                    <p>Place ad banners onto your website to generate revenue.</p>
                </a>
            </li>
            <li>
                <a href="settings/custom-html.php">
                    <i class="material-icons">&#xE86F;</i>
                    <strong>Custom HTML</strong>
                    <p>Add custom HTML code to your site's head and body tags.</p>
                </a>
            </li>
            <li>
                <a href="settings/seo.php">
                    <i class="material-icons">&#xE8B6;</i>
                    <strong>SEO</strong>
                    <p>Change titles and meta tags on the public website.</p>
                </a>
            </li>
            <li>
                <a href="settings/cache.php">
                    <i class="material-icons">&#xE1C2;</i>
                    <strong>Cache</strong>
                    <p>Manage how the application caches tool results.</p>
                </a>
            </li>
            <li>
                <a href="settings/mail.php">
                    <i class="material-icons">&#xE0BE;</i>
                    <strong>Mail</strong>
                    <p>Configure how the system should send outgoing mail.</p>
                </a>
            </li>
            <li>
                <a href="settings/extensions.php">
                    <i class="material-icons">&#xE87B;</i>
                    <strong>Extensions</strong>
                    <p>Manage or install new extensions in the application.</p>
                </a>
            </li>
        </ul>
    </div>
</div>


<?php
$page->footer();
?>
