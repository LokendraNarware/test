<?php

require "includes/init.php";
$page->requirePermission('admin-access');

$studio->setopt("public-url", $_POST['url']);

?>
