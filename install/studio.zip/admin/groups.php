<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(9)->setTitle("Groups")->header();

$q = $studio->sql->query("SELECT * FROM groups ORDER BY id ASC");
?>

<div class="panel">
    <div class="pull-right">
        <a class="btn small blue" href="new-group.php" style="vertical-align: top; margin-top: -5px;">Add a group</a>
    </div>
    <h3><?php echo $q->num_rows; ?> groups</h3>

    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th width="60px" class="center">Id</th>
                    <th>Name</th>
                    <th width="100px" class="center">Users</th>
                    <th width="190px"></th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $q->fetch_array()) {
                ?>
                <tr>
                    <td class="center"><?php echo $row['id']; ?></td>
                    <td><a href="group.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
                    <td class="center"><?php

                    $o = $studio->sql->query("SELECT COUNT(*) FROM accounts WHERE groupId='{$row['id']}'");
                    $r = $o->fetch_array();
                    echo number_format($r[0]);

                    ?></td>
                    <td class="right">
                        <a class="btn tiny" href="group.php?id=<?php echo $row['id']; ?>">Edit</a>
                        <a class="btn tiny red" href="group.php?id=<?php echo $row['id']; ?>&delete">Delete</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$page->footer();
?>
