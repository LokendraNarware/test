<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(23)->setTitle("Store")->header();
?>

<div class="fancy-panel store v2">
    <div><i class="material-icons">&#xE8CB;</i></div>

    <h2>A new store is on the way!</h2>
    <p>You'll be able to download free and premium themes, extensions, and tools from the new store once it's released. Stay tuned!</p>

    <a class="subscribe" target="_blank" href="http://eepurl.com/c-Aqq1">Email me updates</a>
</div>


<?php
$page->footer();
?>
