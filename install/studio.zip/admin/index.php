<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(1)->header();

$data = "";
try {
    $data = $api->getLatestNews();
}
catch (Exception $e) {}
?>

<div class="fancy-panel v2 home">
    <div><i class="material-icons">mail_outline</i></div>

    <h2>Beta testing is open</h2>
    <p style="line-height: 1.7; color: #555;">
        We need help testing the big SEO Studio 2019 update, which was completely redeveloped using a new modern framework.
        If you're willing to encounter issues and help report them, feel free to register below. Testing starts soon.
    </p>

    <a class="subscribe" target="_blank" href="https://baileyherbert.typeform.com/to/PsX3pi">Count me in!</a>
</div>

<div class="fancy-panel v2 home-info color-1">
    <div><i class="material-icons">notifications_none</i></div>

    <h2>Requirements are changing</h2>
    <p>
        Your current version of SEO Studio requires at least PHP 5.4. We're raising this minimum version to 5.6 in the 2019 edition.
        In addition, the upcoming update will be compatible with any one of the following database extensions: pdo_mysql, mysqli, or mysql.
    </p>
</div>

<div class="fancy-panel v2 home-info color-4">
    <div><i class="material-icons">&#xE06D;</i></div>

    <h2>Want a new tool or feature added?</h2>
    <p>
        Let us know using the built-in feedback page by clicking the button below. We won't be able to respond to feedback
        sent through here, but we do see it, and we will take it into consideration for upcoming updates.
    </p>

    <a class="subscribe" href="send-feedback.php">Send feedback</a>
</div>

<?php
$page->footer();
?>
