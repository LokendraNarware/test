<?php

require "includes/init.php";
require "../includes/update.php";

// Validate the parameters and environment

$page->requirePermission('admin-access');
$token = $_POST['token'];

// Run the update

$update = new Update($_POST['token']);
$success = $update->run($studio->getopt("automatic-updates-backup") == "On");

// Done!

die($success ? "successful" : "failed");
?>
