<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(8)->setTitle("Tools")->header();

$data = unserialize($studio->getopt("tools"));
$catData = unserialize($studio->getopt("categories"));

if (isset($_POST['tools']) && isset($_POST['categories'])) {
    $tools = json_decode($_POST['tools'], true);
    $categories = json_decode($_POST['categories'], true);

    if (!is_array($tools) || !is_array($categories)) $studio->showFatalError("Failed to parse JSON formatted POST tools or categories.");

    # Tools array

    $data = array();

    foreach ($categories as $c) {
        $data[$c] = array();
    }

    foreach ($tools as $c => $cTools) {
        foreach ($cTools as $tool) {
            if (!is_array($tool)) continue;

            $data[$c][] = $tool[0];
        }
    }

    $studio->setopt("tools", serialize($data));

    # Categories order

    $data = array();

    foreach ($categories as $i => $c) {
        $data[] = $c;
    }

    $studio->setopt("categories", serialize($data));

    # Update category translations

    $update = array(
        dirname(dirname(__FILE__)) . "/resources/bin/en-us/categories.json"
    );
    $o = $studio->sql->query("SELECT * FROM languages");
    while ($r = $o->fetch_array()) {
        $update[] = dirname(dirname(__FILE__)) . "/resources/languages/{$r['locale']}/categories.json";
    }

    $modified = false;

    foreach ($update as $file) {
        $lang = str_replace("\r\n", "\n", file_get_contents($file));
        $lang = trim(str_replace("\n", "", $lang));
        $lang = preg_replace('/\s+/', ' ', $lang);
        $items = json_decode($lang, true);

        # Remove categories that no longer exist

        foreach ($items as $i=>$v) {
            $i = substr($i, 1);
            if (!in_array($i, $data)) {
                unset($items["@$i"]);
                $modified = true;
            }
        }

        # Add new categories that aren't in the file

        foreach ($data as $c) {
            if (!isset($items["@$c"])) {
                $items["@$c"] = $c;
                $modified = true;
            }
        }

        if (defined("JSON_PRETTY_PRINT")) {
            $new = json_encode($items, JSON_PRETTY_PRINT);
        }
        else {
            $new = json_encode($items);
        }

        $bool = file_put_contents($file, $new);
        if ($bool === false) $studio->showFatalError("Failed to write to $file. Please try making this directory and all files inside have chmod 0777. Contact support for further assistance.");
    }

    if ($modified) {
        header("Location: translate.php?name=categories");
        die;
    }
    else {
        header("Location: tools.php?success=1");
        die;
    }
}

$allToolsList = array();
foreach ($data as $category => $tools) {
    foreach ($tools as $id) {
        $allToolsList[] = $id;
    }
}

$list = $studio->getTools();
$missing = array();

foreach ($list as $tool) {
    if (!in_array($tool->id, $allToolsList)) {
        $missing[] = $tool;
    }
}
?>

<div class="panel">
    <p style="margin: 0;">Click on section titles to edit them. Drag and drop tools to rearrange them. Click the save button to save changes.</p>
</div>

<div class="panel">
    <div class="editor">
        Loading...
    </div>
</div>

<?php
if (count($missing) > 0) {
?>
<div class="panel" id="new">
    <h3>New tools</h3>
    <p>These tools were found but haven't been added to the tools page yet. Drag these icons to a category above to add them.</p>

    <div class="tiles" style="margin: 15px 0 0;">
    <?php
    foreach ($missing as $m) {
    ?>
    <div class="tile" data-cat="" data-tileid="" data-pos="" data-m-toolid="<?php echo $m->id; ?>" data-m-toolicon="<?php echo $m->icon; ?>" data-m-toolname="<?php echo $m->name; ?>">
        <div class="tool-item" data-tool="<?php echo $m->id; ?>">
            <img src="../resources/default-icons/<?php echo $m->icon; ?>.png">
            <span><?php echo $m->name; ?></span>
        </div>
    </div>
    <?php
    }
    ?>
    </div>
</div>
<?php
}
?>

<div class="panel">
    <a class="btn blue saveButton">Save changes</a>
</div>

<form action="" method="post" class="toolsForm">
    <input type="hidden" name="tools">
    <input type="hidden" name="categories">
</form>

<script type="text/javascript">
    var categories = [];
    <?php
    foreach ($catData as $i => $cat) {
        echo "categories[$i] = \"$cat\"" . PHP_EOL . "    ";
    }
    ?>

    var tools = {
        <?php
            foreach ($data as $category => $tools) {
                echo "\"$category\" : [" . PHP_EOL;
                foreach ($tools as $id) {
                    $icon = "";
                    $name = "";
                    foreach ($list as $t) if ($t->id == $id) {
                        $icon = $t->icon;
                        $name = $t->name;
                    }

                    if ($icon != "") echo "            [\"$id\", \"$icon\", \"$name\"]," . PHP_EOL;
                }
                echo "        ]," . PHP_EOL . "        ";
            }
        ?>

    };

    var toolsEditor = true;
</script>

<?php
$page->footer();
?>
