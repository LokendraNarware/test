<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Extensions")->header();

$baseDir = dirname(dirname(dirname(__FILE__)));
$pluginsDir = $baseDir . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "plugins";
$new = 0;

if (!isset($_GET['installed'])) {
    foreach (scandir($pluginsDir) as $dir) {
        if ($dir == "." || $dir == "..") continue;
        if (!is_dir($pluginsDir . "/" . $dir)) continue;

        $p = $studio->sql->prepare("SELECT * FROM plugins WHERE directory = ?");
        $p->bind_param("s", $dir);
        $p->execute();
        $p->store_result();

        if ($p->num_rows == 0) {
            $p->close();

            $className = $dir;
            $file = "$pluginsDir/$dir/$className.php";
            if (!file_exists($file)) continue;
            require_once $file;

            if (!class_exists($className)) continue;

            $o = new $className;
            $name = $o::NAME;
            $version = $o::VERSION;

            $p = $studio->sql->prepare("INSERT INTO plugins (name, directory, market_id, enabled, version, update_available) VALUES (?, ?, 0, 0, ?, '')");
            $p->bind_param("sss", $name, $dir, $version);
            $p->execute();
            $p->close();

            $new++;
            unset($o);
        }
    }
}

if ($new) {
    header("Location: extensions.php?installed=$new");
    die;
}

if (isset($_GET['enable'])) {
    $id = $_GET['enable'];
    if (!is_numeric($id)) die;

    $q = $studio->sql->query("SELECT * FROM plugins WHERE id = $id");
    $r = $q->fetch_object();
    $dir = $r->directory;

    require_once "$pluginsDir/$dir/$dir.php";
    $o = new $dir;
    $o->baseDir = dirname(dirname(dirname(__FILE__)));
    $o->pluginDir = $o->baseDir . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "plugins" . DIRECTORY_SEPARATOR . $dir;

    $studio->sql->query("UPDATE plugins SET enabled = 1 WHERE id = $id");
    $enable = $o->onEnable();
    unset($o);

    if ($enable) {
        header("Location: extensions.php?enabled=1");
        die;
    }
    else {
        $studio->sql->query("UPDATE plugins SET enabled = 0 WHERE id = $id");
        echo "<div class='error'>The plugin failed to enable</div>";
    }
}
if (isset($_GET['disable'])) {
    $id = $_GET['disable'];
    if (!is_numeric($id)) die;

    $q = $studio->sql->query("SELECT * FROM plugins WHERE id = $id");
    $r = $q->fetch_object();
    $dir = $r->directory;

    require_once "$pluginsDir/$dir/$dir.php";
    $o = new $dir;
    $o->baseDir = dirname(dirname(dirname(__FILE__)));
    $o->pluginDir = $o->baseDir . DIRECTORY_SEPARATOR . "includes" . DIRECTORY_SEPARATOR . "plugins" . DIRECTORY_SEPARATOR . $dir;

    $b = $o->onDisable();
    unset($o);

    if ($b !== false) {
        $studio->sql->query("UPDATE plugins SET enabled = 0 WHERE id = $id");
        header("Location: extensions.php?disabled=1");
        die;
    }
}

function delTree($dir) {
    $files = array_diff(scandir($dir), array('.','..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}

if (isset($_GET['uninstall'])) {
    $id = $_GET['uninstall'];
    if (!is_numeric($id)) die;

    $q = $studio->sql->query("SELECT * FROM plugins WHERE id = $id");
    if ($q->num_rows == 0) die;

    $r = $q->fetch_object();
    $dir = $r->directory;

    $studio->sql->query("DELETE FROM plugins WHERE id = $id");

    if (file_exists("$pluginsDir/$dir") && $dir != "") {
        $ok = delTree("$pluginsDir/$dir");
        if (!$ok) {
            echo "<div class='error'>Failed to remove $pluginsDir/$dir directory, please do it manually.</div>";
        }
        else {
            header("Location: extensions.php?uninstalled=1");
            die;
        }
    }
}
?>

<div class="panel">
    <div class="pull-right">
        <a class="btn" href="../install-plugin.php" style="margin-top: -10px;">Install a plugin</a>
    </div>
    <h3>Installed plugins</h3>

    <div class="warning v2">
        <div class="icon">
            <i class="material-icons">&#xE002;</i>
        </div>

        <p>A new extension system is on the way. Your existing plugins will be officially supported on 2016 theme until December 31, 2017. After that, they will keep working, but there's no guarantee that they won't break in a future update. You should move to the new features (when available) before then: Subscriptions, a contact page, and backlinks are all being added as official features in updates coming this November.</p>
    </div>

    <div class="table-container">
        <table class="table plugins">
            <thead>
            <tr>
                <th width="52px"></th>
                <th>Info</th>
                <th class="center" width="140px">Version</th>
                <th class="center" width="140px">Status</th>
                <th class="right" width="260px">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $q = $studio->sql->query("SELECT * FROM plugins ORDER BY id ASC");

            while ($row = $q->fetch_object()) {
                $dname = $row->directory;

                $file = "$pluginsDir/$dname/$dname.php";
                if (!file_exists($file)) {
                    header("Location: extensions.php?uninstall={$row->id}");
                    die;
                }
                require_once $file;

                $o = new $dname;

                $description = $o::DESCRIPTION;
                $settings = $o->settings;

                unset($o);
                ?>
                <tr>
                    <td class="right">
                        <?php echo ($row->enabled ? "<i class='material-icons green'>check_circle</i>" : "<i class='material-icons red'>highlight_off</i>"); ?>
                    </td>
                    <td>
                        <strong><?php echo $row->name; ?></strong>
                        <p><?php echo $description; ?></p>
                    </td>
                    <td class="center"><?php echo $row->version; ?></td>
                    <td class="center"><?php echo ($row->enabled ? "Active" : "Disabled"); ?></td>
                    <td class="right">
                        <?php if ($row->enabled && $settings) { ?>
                            <a class="btn small" href="../plugin-options.php?id=<?php echo $row->id; ?>">Settings</a>
                        <?php } ?>

                        <?php if ($row->market_id > 0) { ?>
                            <a class="btn small" href="https://getseostudio.com/plugins/item?id=<?php echo $row->market_id; ?>" target="_blank">Market</a>
                        <?php } ?>

                        <?php if ($row->enabled) { ?>
                            <a class="btn small" href="?disable=<?php echo $row->id; ?>">Disable</a>
                        <?php } else { ?>
                            <a class="btn small" href="?enable=<?php echo $row->id; ?>">Enable</a>
                            <a class="btn small red" href="?uninstall=<?php echo $row->id; ?>">Uninstall</a>
                        <?php } ?>

                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$page->footer();
?>
