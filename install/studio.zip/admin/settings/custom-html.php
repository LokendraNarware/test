<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Custom HTML")->header();

if (isset($_POST['head'])) {
    $head = $_POST['head'];
    $body = $_POST['body'];

    $studio->setopt("custom-head-html", $head);
    $studio->setopt("custom-body-html", $body);

    header("Location: custom-html.php?success=1");
    die;
}
?>

<form action="" method="post">
    <div class="panel v2 back">
        <a href="../settings.php">
            <i class="material-icons">&#xE5C4;</i> Back to settings
        </a>
    </div>
    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE86F;</i>
            Custom HTML
        </h2>

        <div class="setting-group">
            <h3>Code</h3>

            <div class="setting big-text">
                <label for="Ctl_TextBox_01">Head <span class="help tooltip" title="Enter code to add in the bottom of the <head></head> tag."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_01" name="head"><?php echo $studio->getopt("custom-head-html"); ?></textarea>
                </div>
            </div>

            <div class="setting big-text">
                <label for="Ctl_TextBox_02">Body <span class="help tooltip" title="Enter code to add in the bottom of the <body></body> tag."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_02" name="body"><?php echo $studio->getopt("custom-body-html"); ?></textarea>
                </div>
            </div>
        </div>

        <div class="setting-save">
            <input type="submit" value="Save">
        </div>
    </div>
</form>

<?php
$page->footer();
?>
