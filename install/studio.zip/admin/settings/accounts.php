<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Accounts")->header();

if (isset($_POST['allow-registration'])) {
    $ierror = "";

    $bools = array(
        "allow-registration", "show-login",
        "login-tools", "show-tools"
    );

    foreach ($bools as $bool) {
        if (!isset($_POST[$bool])) $studio->showFatalError("Missing POST parameter $bool");

        $val = $_POST[$bool];
        if ($val != "On" && $val != "Off") $val = "Off";

        $studio->setopt($bool, $val);
    }

    header("Location: accounts.php?success=1&{$ierror}");
    die;
}

?>

<form action="" method="post">
    <div class="panel v2 back">
        <a href="../settings.php">
            <i class="material-icons">&#xE5C4;</i> Back to settings
        </a>
    </div>
    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE7FD;</i>
            Accounts
        </h2>

        <div class="setting-group">
            <h3>Visitors</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_01">Allow visitors to sign up <span class="help tooltip" title="If enabled, visitors on your website can create their own accounts."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_01">
                    <input type="hidden" name="allow-registration" value="<?php echo $studio->getopt("allow-registration"); ?>">
                    <div class="handle"></div>
                </div>
            </div>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_02">Show the login button <span class="help tooltip" title="If disabled, any and all 'login' or 'sign in' buttons will be hidden from the public portal."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_02">
                    <input type="hidden" name="show-login" value="<?php echo $studio->getopt("show-login"); ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-group">
            <h3>Access</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_03">Only logged in users can use tools <span class="help tooltip" title="If enabled, visitors must sign in before they can use any tools."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_03">
                    <input type="hidden" name="login-tools" value="<?php echo $studio->getopt("login-tools"); ?>">
                    <div class="handle"></div>
                </div>
            </div>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_04">Hide the tools page for guests <span class="help tooltip" title="If enabled, the tools page will not be visible in the site navigation unless the user is logged in."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_04">
                    <input type="hidden" name="show-tools" value="<?php echo $studio->getopt("show-tools"); ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-save">
            <input type="submit" value="Save">
        </div>
    </div>
</form>

<?php
$page->footer();
?>
