<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("SEO")->header();

if (isset($_POST['title-home'])) {
    $studio->setopt('title-home', $_POST['title-home']);
    $studio->setopt('description-home', $_POST['description-home']);
    $studio->setopt('title-tools', $_POST['title-tools']);
    $studio->setopt('description-tools', $_POST['description-tools']);

    # Record an array

    $data = array(
        '@PageTitle:Home' => $_POST['title-home'],
        '@PageTitle:Tools' => $_POST['title-tools']
    );

    # Update title translations

    $update = array(
        dirname(dirname(dirname(__FILE__))) . "/resources/bin/en-us/pages.json"
    );

    $o = $studio->sql->query("SELECT * FROM languages");
    while ($r = $o->fetch_array()) {
        $update[] = dirname(dirname(dirname(__FILE__))) . "/resources/languages/{$r['locale']}/pages.json";
    }

    $modified = false;

    foreach ($update as $file) {
        if (!file_exists($file)) file_put_contents($file, "{}");

        $lang = str_replace("\r\n", "\n", file_get_contents($file));
        $lang = trim(str_replace("\n", "", $lang));
        $lang = preg_replace('/\s+/', ' ', $lang);
        $items = json_decode($lang, true);

        # Add new categories that aren't in the file

        foreach ($data as $i => $v) {
            if (!isset($items[$i])) $modified = true;
            if (isset($items[$i]) && $items[$i] != $v) $modified = true;

            $items[$i] = $v;
        }

        if (defined("JSON_PRETTY_PRINT")) {
            $new = json_encode($items, JSON_PRETTY_PRINT);
        }
        else {
            $new = json_encode($items);
        }

        $bool = file_put_contents($file, $new);
        if ($bool === false) $studio->showFatalError("Failed to write to $file. Please try making this directory and all files inside have chmod 0777. Contact support for further assistance.");
    }

    if ($modified) {
        header("Location: ../translate.php?name=pages");
        die;
    }
    else {
        header("Location: seo.php?success=1");
        die;
    }
}
?>


<form action="" method="post">
    <div class="panel v2 back">
        <a href="../settings.php">
            <i class="material-icons">&#xE5C4;</i> Back to settings
        </a>
    </div>
    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE8B6;</i>
            SEO
        </h2>

        <div class="setting-group">
            <h3>Home page</h3>

            <div class="setting small-text">
                <label for="Ctl_TextBox_01">Title <span class="help tooltip" title="Enter the title for the home page. You can translate this to different languages after."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_01" name="title-home"><?php echo $studio->getopt("title-home"); ?></textarea>
                </div>
            </div>

            <div class="setting small-text">
                <label for="Ctl_TextBox_03">Description <span class="help tooltip" title="Enter the home page's meta description, in the default language only."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_03" name="description-home"><?php echo $studio->getopt("description-home"); ?></textarea>
                </div>
            </div>
        </div>

        <div class="setting-group">
            <h3>Tools page</h3>

            <div class="setting small-text">
                <label for="Ctl_TextBox_02">Title <span class="help tooltip" title="Enter the title for the tools page. You can translate this to different languages after."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_02" name="title-tools"><?php echo $studio->getopt("title-tools"); ?></textarea>
                </div>
            </div>

            <div class="setting small-text">
                <label for="Ctl_TextBox_04">Description <span class="help tooltip" title="Enter the tools page's meta description, in the default language only."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_04" name="description-tools"><?php echo $studio->getopt("description-tools"); ?></textarea>
                </div>
            </div>
        </div>

        <div class="setting-save">
            <input type="submit" value="Save">
        </div>
    </div>
</form>


<?php
$page->footer();
?>
