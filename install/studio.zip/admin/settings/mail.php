<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Mail")->header();

if (isset($_POST['smtp-server-port'])) {
    # Update config file if needed

    $ierror = "";

    $ints = array(
        "smtp-server-port"
    );
    $strs = array(
        "mail-server", "email-from", "smtp-server", "smtp-user", "smtp-pass", "mailgun-key", "mailgun-domain"
    );

    foreach ($ints as $int) {
        if (!isset($_POST[$int])) $studio->showFatalError("Missing POST parameter $int");

        $val = $_POST[$int];
        if (!is_numeric($val)) $val = 0;

        $studio->setopt($int, $val);
    }
    foreach ($strs as $str) {
        if (!isset($_POST[$str])) $studio->showFatalError("Missing POST parameter $str");

        $val = $_POST[$str];
        $studio->setopt($str, $val);
    }

    header("Location: mail.php?success=1&{$ierror}");
    die;
}

?>

<form action="" method="post">
    <div class="panel settings">
        <h3>Mail</h3>

        <div class="setting">
            <table>
                <tr>
                    <td width="50%">
                        Email method
                    </td>
                    <td>
                        <select name="mail-server">
                            <option value="php" <?php if ($studio->getopt("mail-server") == "php") echo "selected"; ?>>Built-in PHP mail()</option>
                            <option value="smtp" <?php if ($studio->getopt("mail-server") == "smtp") echo "selected"; ?>>Remote SMTP</option>
                            <option value="mailgun" <?php if ($studio->getopt("mail-server") == "mailgun") echo "selected"; ?>>Mailgun API</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>

        <div class="collapsed mail-server php" style="display: none;">
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            Email From Address
                        </td>
                        <td>
                            <input type="text" name="email-from" value="<?php echo $studio->getopt('email-from'); ?>" placeholder="webmaster@example.com">
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="collapsed mail-server smtp" style="display: none;">
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            SMTP Server
                        </td>
                        <td>
                            <input type="text" name="smtp-server" value="<?php echo $studio->getopt('smtp-server'); ?>" placeholder="Enter server address...">
                        </td>
                    </tr>
                </table>
            </div>
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            SMTP Server Port
                        </td>
                        <td>
                            <input type="text" name="smtp-server-port" class="small" value="<?php echo $p = $studio->getopt('smtp-server-port'); if ($p == null) echo 25; ?>" placeholder="Enter server port...">
                        </td>
                    </tr>
                </table>
            </div>
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            SMTP Username
                        </td>
                        <td>
                            <input type="text" name="smtp-user" value="<?php echo $studio->getopt('smtp-user'); ?>" placeholder="Enter username...">
                        </td>
                    </tr>
                </table>
            </div>
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            SMTP Password
                        </td>
                        <td>
                            <input type="password" name="smtp-pass" value="<?php echo $studio->getopt('smtp-pass'); ?>" placeholder="Enter password...">
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="collapsed mail-server mailgun" style="display: none;">
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            API Key
                        </td>
                        <td>
                            <input type="text" name="mailgun-key" value="<?php echo $studio->getopt('mailgun-key'); ?>" placeholder="Enter API key...">
                        </td>
                    </tr>
                </table>
            </div>
            <div class="setting">
                <table>
                    <tr>
                        <td width="50%">
                            Sending Domain
                        </td>
                        <td>
                            <input type="text" name="mailgun-domain" value="<?php echo $studio->getopt('mailgun-domain'); ?>" placeholder="Enter Mailgun domain...">
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="panel">
        <input type="submit" class="btn blue" value="Save">
    </div>
</form>

<script type="text/javascript">
    $(".collapsed.mail-server." + $("select[name=mail-server]").val()).show();
    $("select[name=mail-server]").on('change', function() {
        $(".collapsed.mail-server").hide();
        $(".collapsed.mail-server." + $("select[name=mail-server]").val()).show();
    });

</script>

<?php
$page->footer();
?>
