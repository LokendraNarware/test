<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Advertising")->header();

if (isset($_POST['enable-ads'])) {
    $bools = array(
        "enable-ads"
    );
    $strs = array(
        "ad-728x90", "ad-120x600", "ad-250x250", "ad-468x60"
    );

    foreach ($bools as $bool) {
        if (!isset($_POST[$bool])) $studio->showFatalError("Missing POST parameter $bool");

        $val = $_POST[$bool];
        if ($val != "On" && $val != "Off") $val = "Off";

        $studio->setopt($bool, $val);
    }
    foreach ($strs as $str) {
        if (!isset($_POST[$str])) $studio->showFatalError("Missing POST parameter $str");

        $val = $_POST[$str];
        $studio->setopt($str, $val);
    }

    header("Location: ads.php?success=1");
    die;
}
?>

<form action="" method="post">
    <div class="panel v2 back">
        <a href="../settings.php">
            <i class="material-icons">&#xE5C4;</i> Back to settings
        </a>
    </div>
    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE3F4;</i>
            Advertising
        </h2>

        <div class="setting-group">
            <h3>Allocation</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_01">Enable advertising banners <span class="help tooltip" title="This option will instruct your current theme to allocate space (if supported) for ad placement."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_01">
                    <input type="hidden" name="enable-ads" value="<?php echo $studio->getopt("enable-ads"); ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-group">
            <h3>Code</h3>

            <div class="setting big-text">
                <label for="Ctl_TextBox_02">Leaderboard (728x90) <span class="help tooltip" title="This slot will fit a 728x90 pixel (or smaller) ad banner. Enter the HTML code for the ad banner here."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_02" name="ad-728x90"><?php echo $studio->getopt("ad-728x90"); ?></textarea>
                </div>
            </div>

            <div class="setting big-text">
                <label for="Ctl_TextBox_03">Skyscraper (120x600) <span class="help tooltip" title="This slot will fit a 120x600 pixel (or smaller) ad banner. Enter the HTML code for the ad banner here."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_03" name="ad-120x600"><?php echo $studio->getopt("ad-120x600"); ?></textarea>
                </div>
            </div>

            <div class="setting big-text">
                <label for="Ctl_TextBox_04">Square (250x250) <span class="help tooltip" title="This slot will fit a 250x250 pixel (or smaller) ad banner. Enter the HTML code for the ad banner here."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_04" name="ad-250x250"><?php echo $studio->getopt("ad-250x250"); ?></textarea>
                </div>
            </div>

            <div class="setting big-text">
                <label for="Ctl_TextBox_05">Banner (468x60) <span class="help tooltip" title="This slot will fit a 468x60 pixel (or smaller) ad banner. Enter the HTML code for the ad banner here."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="text">
                    <textarea id="Ctl_TextBox_05" name="ad-468x60"><?php echo $studio->getopt("ad-468x60"); ?></textarea>
                </div>
            </div>
        </div>

        <div class="setting-save">
            <input type="submit" value="Save">
        </div>
    </div>
</form>

<?php
$page->footer();
?>
