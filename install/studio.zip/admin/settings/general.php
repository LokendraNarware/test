<?php
require "../includes/init.php";
$page->setPath("../../")->requirePermission('admin-access')->setPage(3)->setTitle("Configuration")->header();

if (isset($_POST['show-errors'])) {
    # Update config file if needed

    $ierror = "";

    if ( ($_POST['show-errors'] == "On" && $studio->config['errors']['show'] == false) || ($_POST['show-errors'] == "Off" && $studio->config['errors']['show'] == true) ) {
        $conf = file_get_contents("../../config.php");
        if ($conf === false) $studio->showFatalError("Failed to read /config.php file. Please ensure it has the proper permissions.");

        $current = (($studio->config['errors']['show'] == true) ? "true" : "false");
        $new = (($_POST['show-errors'] == "On") ? "true" : "false");
        $newconf = str_replace('"show" => ' . $current, '"show" => ' . $new, $conf);

        $w = file_put_contents("../../resources/bin/config.backup-".time().".php", $conf);
        if ($w === false) $studio->showFatalError("Failed to make a configuration backup to /resources/bin/, please ensure the directory is writeable.");

        $w = file_put_contents("../../config.php", $newconf);
        if ($w === false) $studio->showFatalError("Failed to overwrite /config.php file, please ensure it is writeable. If you are going to change the chmod, only add writing permissions, do not modify the read permissions.");
    }

    $bools = array(
        "automatic-updates", "automatic-updates-backup", "send-errors", "send-usage-info", "errors-anonymous"
    );

    foreach ($bools as $bool) {
        if (!isset($_POST[$bool])) $studio->showFatalError("Missing POST parameter $bool");

        $val = $_POST[$bool];
        if ($val != "On" && $val != "Off") $val = "Off";

        $studio->setopt($bool, $val);
    }

    header("Location: general.php?success=1&{$ierror}");
    die;
}

?>

<form action="" method="post">
    <div class="panel v2 back">
        <a href="../settings.php">
            <i class="material-icons">&#xE5C4;</i> Back to settings
        </a>
    </div>
    <div class="panel v2">
        <h2>
            <i class="material-icons">&#xE8B8;</i>
            Configuration
        </h2>

        <div class="setting-group">
            <h3>Studio</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_01">Automatically update Studio <span class="help tooltip" title="The application will automatically be updated to the latest version. This might overwrite any changes you make to the script's code."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_01">
                    <input type="hidden" name="automatic-updates" value="<?php echo $studio->getopt("automatic-updates"); ?>">
                    <div class="handle"></div>
                </div>
            </div>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_02">Save files before updating <span class="help tooltip" title="If enabled, a backup .zip file containing the previous version of all files modified by updates will be saved to the disk, in case something goes wrong or gets overwritten accidentally."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_02">
                    <input type="hidden" name="automatic-updates-backup" value="<?php echo $studio->getopt("automatic-updates-backup"); ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-group">
            <h3>Errors</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_04">Send errors to the developer <span class="help tooltip" title="When an error occurs in the script, it will be sent to the developer so that it may be fixed in future versions. If you don't want to send errors, or are modifying the script, you should turn this option off."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_04">
                    <input type="hidden" name="send-errors" value="<?php echo $studio->getopt("send-errors"); ?>">
                    <div class="handle"></div>
                </div>
            </div>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_05">Anonymous error reports <span class="help tooltip" title="If enabled, any error reports your script sends to the developer will be anonymous. If disabled, the developer will be sent your Envato username so he can see the error if you contact support."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_05">
                    <input type="hidden" name="errors-anonymous" value="<?php echo $studio->getopt("errors-anonymous"); ?>">
                    <div class="handle"></div>
                </div>
            </div>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_03">Show errors <span class="help tooltip" title="If enabled, any errors the script encounters will be shown in full detail. This should be turned off in production."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_03">
                    <input type="hidden" name="show-errors" value="<?php if ($studio->config['errors']['show'] == true) echo "On"; else echo "Off"; ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-group">
            <h3>Telemetry</h3>

            <div class="setting toggle">
                <label data-switch="Ctl_Switch_06">Send anonymous usage info <span class="help tooltip" title="Automatically send telemetry including tool usage and software versions to support development. We'll use this information to update the most popular features first."><i class="material-icons">&#xE8FD;</i></span></label>

                <div class="switch" id="Ctl_Switch_06">
                    <input type="hidden" name="send-usage-info" value="<?php echo $studio->getopt("send-usage-info"); ?>">
                    <div class="handle"></div>
                </div>
            </div>
        </div>

        <div class="setting-save">
            <input type="hidden" name="url">
            <input type="submit" value="Save">
        </div>
    </div>
</form>

<script type="text/javascript">
    $("input[name=url]").val(window.location.href);
</script>

<?php
$page->footer();
?>
