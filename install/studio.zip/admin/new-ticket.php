<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(16)->setTitle("Customer Support")->header();

if (!$api->isAuthorized()) {
    require "_locked.php";
    $page->footer();
    $studio->stop();
}

if (isset($_POST['subject'])) {
    $subject = $_POST['subject'];
    $mailbox = $_POST['department'];
    $message = $_POST['message'];
    $email = $_POST['email'];

    try {
        $success = $api->createTicket($email, $message, $subject, $mailbox);

        if (!$success) {
            echo "<div class='error'>Failed to submit the ticket. Please make sure you entered a message and that your email is valid.</div>";
        }
        else {
            header("Location: support.php?success=1");
            die;
        }
    }
    catch (Exception $e) {
        echo "<div class='error'>{$e->getMessage()}</div>";
    }
}
?>


<form action="" method="post">
    <div class="panel">
        <h3>Create New Ticket</h3>

        <p>Your Email</p>
        <input type="text" class="fancy" name="email" value="<?php if (isset($_POST['email'])) echo $studio->attr($_POST['email']); ?>">

        <p>Subject</p>
        <input type="text" class="fancy" name="subject" value="<?php if (isset($_POST['subject'])) echo $studio->attr($_POST['subject']); ?>">

        <p>Department</p>
        <select class="fancy" name="department">
            <option value="support">Support</option>
            <option value="sales">Sales & Billing</option>
        </select>

        <p>Message</p>
        <textarea class="fancy" name="message" rows="12"><?php if (isset($_POST['message'])) echo $_POST['message']; ?></textarea>

        <input type="submit" class="btn blue" value="Submit">
    </div>
</form>

<?php
$page->footer();
?>
