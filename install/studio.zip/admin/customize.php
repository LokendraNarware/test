<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(19)->setTitle("Customize")->header();
?>

<div class="panel v2">
    <h2>
        <i class="material-icons">&#xE3B7;</i>
        Customize
    </h2>

    <div class="info v2">
        <div class="icon">
            <i class="material-icons">&#xE88E;</i>
        </div>

        <p>Themes are coming soon in a new update. They'll be on this page once they're ready.</p>
    </div>

    <div class="menu v2">
        <ul>
            <li>
                <a href="header.php">
                    <i class="material-icons">&#xE069;</i>
                    <strong>Header</strong>
                    <p>Change the website logo and other theme options.</p>
                </a>
            </li>
            <li>
                <a href="homepage.php">
                    <i class="material-icons">&#xE88A;</i>
                    <strong>Home Page</strong>
                    <p>Modify the text on the home page, and more coming soon.</p>
                </a>
            </li>
        </ul>
    </div>
</div>


<?php
$page->footer();
?>
