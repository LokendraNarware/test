<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(11)->setTitle("Languages")->header();

$q = $studio->sql->query("SELECT * FROM languages ORDER BY id ASC");

if (isset($_POST['default'])) {
    $default = $_POST['default'];
    if (!is_numeric($default)) die;

    $checkq = $studio->sql->query("SELECT * FROM languages WHERE id = $default");
    if ($checkq->num_rows !== 1) die;
    $r = $checkq->fetch_array();

    $studio->setopt("default-language", $r['locale']);

    header("Location: languages.php");
    die;
}
?>

<div class="panel">
    <div class="pull-right">
        <a class="btn small blue" href="new-language.php" style="vertical-align: top; margin-top: -5px;">Create new</a>
    </div>
    <h3><?php echo $q->num_rows; ?> languages</h3>

    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th width="80px" class="center">Id</th>
                    <th width="240px">Name</th>
                    <th width="100px">Locale</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $q->fetch_array()) {
                ?>
                <tr>
                    <td class="center"><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['locale']; ?></td>
                    <td class="right">
                        <a class="btn tiny" href="language.php?id=<?php echo $row['id']; ?>">Edit</a>
                        <a class="btn tiny red" href="language.php?id=<?php echo $row['id']; ?>&delete">Delete</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div class="panel">
    <h3>Default Language</h3>
    <p>Choose the default language for new visitors.</p>

    <form style="margin: 15px 0 0;" method="post" action="">
        <select class="fancy" name="default">
            <?php
                $lang = $studio->getopt('default-language');
                $q = $studio->sql->query("SELECT * FROM languages ORDER BY id ASC");
                while ($row = $q->fetch_array()) {
            ?>
            <option value="<?php echo $row['id']; ?>"<?php if ($row['locale'] == $lang) echo " selected"; ?>><?php echo $row['name']; ?></option>
            <?php
                }
            ?>
        </select>

        <input type="submit" class="btn blue" value="Update">
    </form>
</div>

<?php
$page->footer();
?>
