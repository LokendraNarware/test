<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(16)->setTitle("Help")->header();

$auth = urlencode(base64_encode($studio->getopt("api.secretkey")));
$code = "";

if ($api->isAuthorized()) {
    try {
        $info = $api->getApplicationInfo();
        $code = $info->purchase_code;
    }
    catch (\Exception $e) {}
}

?>


<div class="panel v2">
    <h2>
        <i class="material-icons">&#xE8FD;</i>
        Help
    </h2>

    <div class="menu v2">
        <ul>
            <li>
                <a href="../content/documents/documentation.html" target="_blank">
                    <i class="material-icons">&#xE24D;</i>
                    <strong>Documentation</strong>
                    <p>View product documentation for usage and other general info.</p>
                </a>
            </li>
            <li>
                <a href="diagnostics.php">
                    <i class="material-icons">&#xE868;</i>
                    <strong>Diagnostics</strong>
                    <p>Run automatic tests to find issues and errors in your app.</p>
                </a>
            </li>
            <li>
                <a href="https://baileyherbert.com/support/r/purchase?code=<?php echo $code; ?>">
                    <i class="material-icons">&#xE887;</i>
                    <strong>Contact support</strong>
                    <p>Send an email to customer support. We're ready to assist you.</p>
                </a>
            </li>
            <li>
                <a href="send-feedback.php">
                    <i class="material-icons">&#xE87F;</i>
                    <strong>Request a feature</strong>
                    <p>Have a brilliant new idea? Send it to us using this feedback form.</p>
                </a>
            </li>
        </ul>
    </div>
</div>


<?php
$page->footer();
?>
