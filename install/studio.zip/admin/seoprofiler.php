<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(13)->setTitle("SEO Profiler")->header();
?>



<?php
$page->footer();
?>
