<?php
require "includes/init.php";

$id = $_GET['id'];
if (!is_numeric($id)) die;

$q = $studio->sql->query("SELECT * FROM languages WHERE id = $id");
if ($q->num_rows == 0) die("404");

$lang = $q->fetch_array();
$file = dirname(dirname(__FILE__)) . "/resources/languages/" . $lang['locale'] . "/";
if (!file_exists($file)) die("Not found: $file");

$page->setPath("../")->requirePermission('admin-access')->setPage(11)->setTitle($lang['name'])->header();

if (isset($_GET['cdelete'])) {
    if ($studio->getopt("default-language") == $lang['locale']) die("You cannot delete this language because it is currently set as the default.");

    $studio->sql->query("DELETE FROM languages WHERE id = $id");

    header("Location: languages.php");
    die;
}

if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $locale = $_POST['locale'];
    $dir = $_POST['dir'];
    $google = $_POST['google'];

    foreach (scandir($file) as $f) {
        if (substr($f, 0, 1) == ".") continue;

        $data = str_replace("\r\n", "\n", file_get_contents($file . $f));
        $data = trim(str_replace("\n", "", $data));
        $data = preg_replace('/\s+/', ' ', $data);

        $items = json_decode($data, true);

        foreach ($items as $in => $out) {
            if (!isset($_POST[basename(str_replace(".", "_", $f), '.json') . ':' . md5($in)])) die("Missing field: $in");

            $items[$in] = $_POST[basename(str_replace(".", "_", $f), '.json') . ':' . md5($in)];
        }

        if (defined("JSON_PRETTY_PRINT")) {
            $new = json_encode($items, JSON_PRETTY_PRINT);
        }
        else {
            $new = json_encode($items);
        }

        $bool = file_put_contents($file . $f, $new);
        if ($bool === false) $studio->showFatalError("Failed to write to $file. Please try making this directory and all files inside have chmod 0777. Contact support for further assistance.");
    }

    $p = $studio->sql->prepare("UPDATE languages SET name=?, locale=?, dir=?, google=? WHERE id=$id");
    $p->bind_param("ssss", $name, $locale, $dir, $google);
    $p->execute();
    $p->close();

    if ($locale != $lang['locale']) {
        // we changed names

        $base = dirname(dirname(__FILE__)) . "/resources/languages/";
        if (file_exists($base . $name)) {
            rename($base . $name, $base . $name . "-old-" . rand());
        }
        $bool = rename($base . $lang['locale'], $base . $locale);
        if ($bool === false) {
            $studio->throwFatalError("Failed to move {$base}{$lang['locale']}: permission denied");
        }

        if ($studio->getopt("default-language") == $lang['locale']) {
            $studio->setopt("default-language", $locale);
        }
    }

    header("Location: language.php?id=$id&success=1");
    die;
}
?>

<?php if (isset($_GET['delete'])) { ?>

<div class="panel">
    <h3>Confirm Deletion</h3>
    <p style="margin: 0 0 15px;">The language will be removed from the database, but the language files (located in /resources/languages/<?php echo $lang['locale']; ?>/) will not be deleted from the disk.</p>

    <a class="btn red" href="?id=<?php echo $id; ?>&cdelete=1">Delete</a>
    <a class="btn" href="?id=<?php echo $id; ?>">Cancel</a>
</div>

<?php } ?>

<form action="" method="post">
    <div class="panel">
        <h3>Language settings</h3>

        <div class="row">
            <div class="col-md-6">
                <div style="margin: 0 0 15px;">
                    <p style="margin: 0 0 2px;">Display Name</p>
                    <input type="text" name="name" class="fancy" value="<?php echo $studio->attr($lang['name']); ?>" style="margin: 0;">
                </div>

                <div style="margin: 0;">
                    <p style="margin: 0 0 2px;">Locale</p>
                    <select name="locale" class="fancy">
                        <?php
                        $locales = trim(file_get_contents(dirname(dirname(__FILE__)) . "/resources/bin/locales"));
                        $locales = explode("\n", $locales);

                        foreach ($locales as $locale) {
                            $locale = trim($locale);
                        ?>
                        <option value="<?php echo $locale; ?>" <?php if ($lang['locale'] == $locale) echo "selected"; ?>><?php echo $locale; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div style="margin: 0 0 15px;">
                    <p style="margin: 0 0 2px;">Display</p>
                    <select name="dir" class="fancy" style="margin: 0;">
                        <option value="ltr" <?php if ($lang['dir'] == "ltr") echo "selected"; ?>>Left to right</option>
                        <option value="rtl" <?php if ($lang['dir'] == "rtl") echo "selected"; ?>>Right to left</option>
                    </select>
                </div>

                <div style="margin: 0;">
                    <p style="margin: 0 0 2px;">Google</p>
                    <select name="google" class="fancy" style="margin: 0;">
                        <?php
                        $googles = trim(file_get_contents(dirname(dirname(__FILE__)) . "/resources/bin/google"));
                        $googles = explode("\n", $googles);

                        foreach ($googles as $google) {
                            $google = trim($google);
                        ?>
                        <option value="<?php echo $google; ?>" <?php if ($lang['google'] == $google) echo "selected"; ?>><?php echo $google; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>

        <input type="submit" class="btn blue" value="Save">
    </div>

    <?php
    foreach (scandir($file) as $f) {
        if (substr($f, 0, 1) == ".") continue;

        $data = str_replace("\r\n", "\n", file_get_contents($file . $f));
        $data = trim(str_replace("\n", "", $data));
        $data = preg_replace('/\s+/', ' ', $data);

        $items = json_decode($data, true);

        echo "<div class=\"panel\"><div class='pull-right'><a class='btn small raw'>Raw</a></div><h3>{$f}</h3>";
        echo "<table class=\"translate\">";

        foreach ($items as $in => $out) {
    ?>
    <tr>
        <td><?php echo $in; ?></td>
        <td><input type="text" name="<?php echo basename(str_replace(".", "_", $f), '.json') . ':' . md5($in); ?>" value="<?php echo $studio->attr($out); ?>"></td>
    </tr>
    <?php
        }

        echo "</table>";
        echo "<pre class='code-editor hidden'>" . file_get_contents($file . $f) . "</pre></div>";
    }
    ?>

    <div class="panel">
        <input type="submit" class="btn blue" value="Save">
    </div>
</form>

<?php
$page->footer();
?>
