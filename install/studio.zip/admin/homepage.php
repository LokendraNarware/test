<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(7)->setTitle("Homepage")->header();
?>

<div class="panel">
    <h3>Homepage text</h3>
    <p>You can use the translation system to modify the homepage's text.</p>

    <a class="btn" style="margin: 10px 0 0;" href="translate.php?name=home">Edit text</a>
</div>

<?php
$page->footer();
?>
