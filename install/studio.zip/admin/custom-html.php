<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(21)->setTitle("Custom HTML")->header();

if (isset($_POST['head'])) {
    $head = $_POST['head'];
    $body = $_POST['body'];

    $studio->setopt("custom-head-html", $head);
    $studio->setopt("custom-body-html", $body);

    header("Location: custom-html.php?success=1");
    die;
}
?>

<form action="" method="post">

    <div class="panel">
        <h3>Head</h3>
        <p>Place any custom code meant to go inside the &lt;head&gt; tag here.</p>

        <textarea name="head" class="fancy" style="margin: 20px 0 0;" rows="6"><?php echo $studio->getopt("custom-head-html"); ?></textarea>
    </div>

    <div class="panel">
        <h3>Body</h3>
        <p>Place any custom code meant to go at the end of the &lt;body&gt; tag here.</p>

        <textarea name="body" class="fancy" style="margin: 20px 0 0;" rows="6"><?php echo $studio->getopt("custom-body-html"); ?></textarea>
    </div>

    <div class="panel">
        <input type="submit" class="btn blue" value="Save">
    </div>

</form>

<?php
$page->footer();
?>
