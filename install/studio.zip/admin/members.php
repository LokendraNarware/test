<?php
require "includes/init.php";
$page->setPath("../")->requirePermission('admin-access')->setPage(9)->setTitle("Members")->header();
?>

<div class="panel v2">
    <h2>
        <i class="material-icons">&#xE7FB;</i>
        Members
    </h2>

    <div class="menu v2">
        <ul>
            <li>
                <a href="users.php">
                    <i class="material-icons">&#xE7FF;</i>
                    <strong>Users</strong>
                    <p>Manage individual users or create new users manually.</p>
                </a>
            </li>
            <li>
                <a href="groups.php">
                    <i class="material-icons">&#xE7FC;</i>
                    <strong>Groups</strong>
                    <p>Manage user groups and their permissions.</p>
                </a>
            </li>
        </ul>
    </div>
</div>


<?php
$page->footer();
?>
