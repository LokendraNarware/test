<?php

require "includes/init.php";
$page->setTitle("Tools")->setPage(2)->header();

if (isset($_GET['site']) && $account->isLoggedIn()) {
    if ($p = $studio->sql->prepare("SELECT domain, userId FROM websites WHERE userId = {$account->getId()} AND domain LIKE ? ORDER BY timeCreated DESC")) {
        $p->bind_param("s", $_GET['site']);
        $p->execute();
        $p->store_result();

        if ($p->num_rows == 1) {
            $p->bind_result($domain, $userId);
            $p->fetch();

            $account->setCurrentWebsite($domain);
            $studio->redirect("tools.php");
        }
        else {
            $studio->redirect("account/websites.php");
        }
    }
}
elseif (isset($_GET['site'])) {
    $site = $_GET['site'];

    try {
        $url = new \SEO\Helper\Url($site);
        $account->setCurrentWebsite($url->domain);
        $studio->redirect("tools.php");
    }
    catch (Exception $e) {
        $badInput = true;
    }
}

?>

<section class="website">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
        <?php
        if ($account->isLoggedIn()) {
        ?>
        <div class="select">
            <div class="label">
                <span><?php

                $site = $account->getCurrentWebsite();
                if ($site != null) {
                    echo $site;
                }
                else {
                    echo rt("Select a website");
                }

                ?></span>
                <div class="arrow-down"></div>
            </div>
            <div class="dropdown">
                <ul>
                    <?php
                    $websites = $studio->sql->query("SELECT domain, userId FROM websites WHERE userId = {$account->getId()} ORDER BY timeCreated DESC");

                    if ($websites->num_rows == 0) {
                    ?>
                    <li>
                        <a><?php pt("You haven't added any sites yet."); ?></a>
                    </li>
                    <?php
                    }
                    else {
                        while ($site = $websites->fetch_array()) {
                            $active = "";

                            if ($account->getCurrentWebsite() == $site['domain']) $active = " class=\"active\"";
                    ?>
                    <li<?php echo $active; ?>><a href="?site=<?php echo $site['domain']; ?>"><?php echo $site['domain']; ?></a></li>
                    <?php
                        }
                    }
                    ?>
                    <li><hr /></li>
                    <li><a href="account/websites.php"><div class="icon" data-icon="P"></div> <?php pt("Manage sites"); ?></a></li>
                </ul>
            </div>
        </div>
        <?php
        }
        else {
        ?>
        <form action="" method="get">
            <input type="text" name="site" placeholder="<?php pt("Click here to enter a website..."); ?>" value="<?php

            $site = $account->getCurrentWebsite();
            if ($site != null) echo $site;

            ?>"/>
        </form>
        <?php
        }
        ?>
            </div>
            <div class="col-md-6">
                <?php
                $plugins->call("tools_website_picker_right");
                ?>
            </div>
        </div>
    </div>
</section>

<section class="tools">
    <div class="container">
        <?php

        if (isset($badInput)) $studio->showError(rt("Please enter a valid website."));

        $site = $account->getCurrentWebsite();
        if ($site == null) {
            if ($account->isLoggedIn()) $message = rt("Choose a website from the dropdown above to get started.");
            else $message = rt("Enter a website above to get started.");

            echo "<h3>$message</h3>";
            $page->footer();
            die;
        }

        $tools = unserialize($studio->getopt("tools"));
        $categories = unserialize($studio->getopt("categories"));

        $toolClasses = $studio->getTools();

        //$r = count($tools);
        //echo "<strong>{$r} tools</strong><br /><br />";

        //foreach ($tools as $tool) {
        //    echo "<a href=\"tool.php?id={$tool->id}\">{$tool->name}</a><br />";
        //}

        if ($studio->getopt("ad-120x600") && $studio->getopt("enable-ads") == "On") {
            echo "<div class=\"row\">";
            echo "<div class=\"col-md-10\">";
        }
        $plugins->call("tools_before");

        foreach ($categories as $cat) {
            $sectionTools = $tools[$cat];

        ?>

        <div class="category">
            <h2><?php echo rt("@$cat"); ?></h2>

            <div class="tools">
        <?php
            foreach ($sectionTools as $id) {
                $icon = "";
                $name = "";
                foreach ($toolClasses as $t) if ($t->id == $id) {
                    $icon = $t->icon;
                    $name = $t->name;
                }

                if ($icon != "") {
        ?>
                <a class="tool" href="tool.php?id=<?php echo $id; ?>">
                    <div class="tool-loader"></div>
                    <div class="tc">
                        <div>
                            <img src="resources/icons/<?php echo $icon; ?>.png">
                            <span><?php echo rt($name); ?></span>
                        </div>
                    </div>
                </a>
        <?php
                }
            }
        ?>
            </div>
        </div>

        <?php
            if (rand(1,10) == 5) {
                new Studio\Display\Ad("468x60", "margin: -20px 0 35px;");
            }

            $plugins->call("tools_category_after");
        }

        if ($studio->getopt("ad-120x600") && $studio->getopt("enable-ads") == "On") {
            echo "</div>";
            echo "<div class=\"col-md-2\">";
            new Studio\Display\Ad("120x600", "text-align: center; margin: 0 0 20px;");
            new Studio\Display\Ad("120x600", "text-align: center;");
            echo "</div></div>";
        }

        $plugins->call("tools_after");
        ?>

    </div>
</section>

<div style="width: 1px; height: 1px; overflow: hidden;">
    <img src="resources/images/b-load32.gif">
</div>

<?php
$page->footer();
?>
