<?php

require "../includes/init.php";
$page->setTitle("Login")->setPage(3)->setPath("../")->header();

if (isset($_SESSION[$account->sessname])) {
    header("Location: index.php");
    $studio->stop();
}

$form = new \Studio\Forms\LoginForm;

?>

<section class="title">
    <div class="container">
        <h1><?php pt("Login"); ?></h1>
    </div>
</section>

<section class="login-form">
    <div class="container">
        <form action="" method="post">
            <?php
            $form->showErrors();
            ?>
            <input type="text" name="email" placeholder="<?php pt("Email address"); ?>" value="<?php if (isset($_POST['email'])) echo $studio->attr($_POST['email']); ?>" />
            <input type="password" name="password" placeholder="<?php pt("Password"); ?>" />
            <input type="submit" value="<?php pt("Login"); ?>" />

            <div class="info">
                <a href="register.php"><?php pt("create an account"); ?></a>
            </div>
        </form>
    </div>
</section>

<?php
$page->footer();
?>
