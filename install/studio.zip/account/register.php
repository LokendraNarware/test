<?php

require "../includes/init.php";
$page->setTitle("Register")->setPage(3)->setPath("../")->header();

if ($studio->getopt("allow-registration") == "Off") {
    $page->footer();
    $studio->stop();
}

if (isset($_SESSION[$account->sessname])) {
    header("Location: index.php");
    $studio->stop();
}

$form = new \Studio\Forms\RegisterForm;

?>

<section class="title">
    <div class="container">
        <h1><?php pt("Register"); ?></h1>
    </div>
</section>

<section class="login-form">
    <div class="container">
        <form action="" method="post">
            <?php
            $form->showErrors();
            ?>
            <input type="text" name="email" placeholder="<?php pt("Email address"); ?>" />
            <input type="password" name="password" placeholder="<?php pt("Password"); ?>" />
            <input type="password" name="password2" placeholder="<?php pt("Repeat password"); ?>" />

            <?php
            $plugins->call("register_form");
            ?>

            <input type="submit" value="<?php pt("Register"); ?>" />

            <div class="info">
                <?php pt("Already have an account?"); ?> <a href="login.php"><?php pt("Login"); ?></a>
            </div>
        </form>
    </div>
</section>

<?php
$page->footer();
?>
