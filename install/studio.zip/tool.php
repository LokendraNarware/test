<?php

require "includes/init.php";

if (!isset($_GET['id'])) {
    $studio->redirect("tools.php");
}

if (!$account->isLoggedIn() && $studio->getopt("login-tools") == "On") {
    $_SESSION['return'] = (isset($_GET['id']) ? urlencode($_GET['id']) : "");
    $studio->redirect("account/login.php");
}

$tools = $studio->getTools();
$tool = null;

foreach ($tools as $t) {
    if ($t->id == $_GET['id']) {
        $tool = $t;
    }
}

if ($account->getCurrentWebsite() == null) {
    $studio->redirect("tools.php");
}

if ($tool == null) {
    $page->setTitle("Not Found")->setPage(2.5)->header();

    echo "<section class=\"generic\">
        <div class=\"container\">
            <h3>" . rt("Tool not found") . "</h3>
        </div>
    </section>";

    if (function_exists('http_response_code')) {
        http_response_code(404);
    }

    $page->footer();
    die;
}

$plugins->call("tool_init", [$tool->id]);

$tool->prerun($account->getCurrentWebsite());
$page->setTitle(rt($tool->name))->setPage(2.5)->header();
?>

<section class="title">
    <div class="container">
        <h1><?php echo rt($tool->name); ?></h1>
    </div>
</section>

<?php

new Studio\Display\Ad("728x90", "text-align: center; margin: 25px 0 -10px;");

try {
    $url = new \SEO\Helper\Url($account->getCurrentWebsite());
    $plugins->call("tool_head", [$tool, $url]);
    $tool->start($url);
}
catch (Exception $e) {
    $plugins->call("tool_error");
    echo "<section class=\"generic error-message\">
        <div class=\"container\">
            <div>
                <img src=\"{$page->getPath()}resources/images/error128.png\" width=\"64px\" />
            </div>
            <p>{$studio->ptext($e->getMessage())}</p>
        </div>
    </section>";

    $page->footer();
    die;
}
$plugins->call("tool_foot", [$tool, $url]);



$page->footer();
?>
