<?php global $account; ?>
<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>SEO Studio</title>

        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,400italic,500,700,700italic,900|Source+Code+Pro">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" type="text/css" href="<?php echo $this->getPath(); ?>resources/styles/grid.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $this->getPath(); ?>resources/styles/admin.css?v=<?php echo \Studio\Base\Studio::VERSION_STR; ?>">

        <!--[if lte IE 7]><script src="<?php echo $this->getPath(); ?>resources/scripts/icons-lte-ie7.js"></script><![endif]-->

        <script type="text/javascript" src="<?php echo $this->getPath(); ?>resources/scripts/jquery-1.12.3.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->getPath(); ?>resources/scripts/jquery-ui.min.js"></script>
    </head>
    <body>
        <div class="sidebar">
            <div class="head">
                <img src="<?php echo $this->getPath(); ?>resources/images/admin-logo.png" class="logo">
            </div>
            <div class="padding">

                <a href="<?php echo $this->getPath(); ?>admin/" <?php $this->activeLink(1, 'active'); ?>><i class="material-icons">&#xE88A;</i> Dashboard</a>
                <a href="<?php echo $this->getPath(); ?>admin/tools.php" <?php $this->activeLink(8, 'active'); ?>><i class="material-icons">&#xE87B;</i> Tools</a>
                <a href="<?php echo $this->getPath(); ?>admin/customize.php" <?php $this->activeLink(19, 'active'); ?>><i class="material-icons">&#xE3B7;</i> Customize</a>
                <a href="<?php echo $this->getPath(); ?>admin/members.php" <?php $this->activeLink(9, 'active'); ?>><i class="material-icons">&#xE7FB;</i> Members</a>
                <a href="<?php echo $this->getPath(); ?>admin/languages.php" <?php $this->activeLink(11, 'active'); ?>><i class="material-icons">&#xE894;</i> Language</a>
                <a href="<?php echo $this->getPath(); ?>admin/services.php" <?php $this->activeLink(22, 'active'); ?>><i class="material-icons">&#xE2BD;</i> Services <?php if ($this->studio->getopt('cron-last-run') < (time() - 43200)) echo "<span class=\"notification issue\">1</span>"; ?></a>
                <a href="<?php echo $this->getPath(); ?>admin/store.php" <?php $this->activeLink(23, 'active'); ?>><i class="material-icons">&#xE8CB;</i> Store</a>
                <?php $this->studio->getPluginManager()->call("admin_nav"); ?>
                <a href="<?php echo $this->getPath(); ?>admin/settings.php" <?php $this->activeLink(3, 'active'); ?>><i class="material-icons">&#xE8B8;</i> Settings</a>
                <a href="<?php echo $this->getPath(); ?>admin/updates.php" <?php $this->activeLink(14, 'active'); ?>><i class="material-icons">&#xE923;</i> Updates <?php if ($update_count > 0) echo "<span class=\"notification\">$update_count</span>"; ?></a>
                <a href="<?php echo $this->getPath(); ?>admin/support.php" <?php $this->activeLink(16, 'active'); ?>><i class="material-icons">&#xE8FD;</i> Help</a>

                <a href="<?php echo $this->getPath(); ?>" class="public"><i class="material-icons">&#xE417;</i> View website</a>

            </div>
        </div>

        <div class="header">
            <div class="user-controls">
                <ul>
                    <li><a class="controls--user"><i class="material-icons">&#xE853;</i></a></li>
                </ul>
            </div>
        </div>

        <div class="user-control hidden">
            <div class="embed">
                <h2><?php echo $account->getEmail(); ?></h2>

                <ul>
                    <li><a href="<?php echo $this->getPath(); ?>account/settings.php">Edit account</a></li>
                    <li><a href="<?php echo $this->getPath(); ?>admin/logout.php">Sign out</a></li>
                </ul>
            </div>
        </div>

        <div class="body">

            <?php
            if (isset($_GET['success'])) {
            ?>
            <div class="success">
                Success!
            </div>
            <?php
            } ?>

            <?php

            $install = dirname(dirname(dirname(__FILE__))) . "/install/index.php";
            if (file_exists($install)) {
            ?>
            <div class="error">
                The install/ directory couldn't be automatically deleted. You must manually delete this directory.
            </div>
            <?php
            }

            $data = unserialize($this->studio->getopt("tools"));
            $catData = unserialize($this->studio->getopt("categories"));

            $allToolsList = array();
            foreach ($data as $category => $tools) {
                foreach ($tools as $id) {
                    $allToolsList[] = $id;
                }
            }

            $list = $this->studio->getTools();
            $missing = array();

            foreach ($list as $tool) {
                if (!in_array($tool->id, $allToolsList)) {
                    $missing[] = $tool;
                }
            }

            if (count($missing) > 0) {
            ?>
            <a href="tools.php#new" style="text-decoration: none !important;"><div class="warning">
                There are tools that have been installed but are not added to the tools page. Click here to add them.
            </div></a>
            <?php
            }

            if ($this->studio->getopt('cron-last-run') < (time() - 43200) && $this->getPage() != 18) {
                if (isset($_GET['hidewarning']) && $_GET['hidewarning'] == "1") {
                    $_SESSION['hideWarning1'] = true;
                }
                if (!isset($_SESSION['hideWarning1'])) {
            ?>
            <!--<div class="warning">
                The cron job is not configured properly. Please <a href="cron.php">click here</a> to configure it.
                <a class="closeButton" href="?hidewarning=1">&times;</a>
            </div>-->
            <?php
                }
            }

            $this->studio->getPluginManager()->call("admin_head");
            ?>
