        <?php $this->studio->getPluginManager()->call("footer"); ?>

        <script type="text/javascript" src="<?php echo $this->getPath(); ?>resources/scripts/jquery-1.12.3.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->getPath(); ?>resources/scripts/jquery-ui.min.js"></script>
        <script type="text/javascript">
            var path = "<?php echo $this->getPath(); ?>";
        </script>
        <script type="text/javascript" src="<?php echo $this->getPath(); ?>resources/scripts/studio.js"></script>

        <?php echo $this->studio->getopt("custom-body-html"); ?>
    </body>
</html>
