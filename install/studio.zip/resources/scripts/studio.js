$(function() {
    loadWebsiteSwitcher();
    hideErrors();
    stickyTables();
    submitLoaders();
    animateToolIcons();

    if (typeof submitSitemaps !== "undefined") submitSitemapHandler();

    $(".language-bar .dropdown").click(function() {
        if ($(this).hasClass("active")) {
            $(this).removeClass("active");
            $(".language-menu").hide();
        }
        else {
            $(this).addClass("active");
            $(".language-menu").show();
        }
    });
});

var stickyId = "";

function animateToolIcons() {
    $(".category .tool").click(function() {
        if ($(this).hasClass("is-loading")) return false;
        $(this).addClass("is-loading");

        $(this).find(".tool-loader").show().html("<img src=\"resources/images/b-load32.gif\">");
    });
}

function submitLoaders() {
    $(".form-container input[type=submit]").click(function() {
        var btn = $(this);
        setTimeout(function() {
            btn.parent().html("<img src=\"" + path + "resources/images/load32.gif\" alt=\"Loading\" width=\"16px\">");
        }, 20);
    });
}

function stickyTables() {
    $(window).scroll(function() {
        $("table[data-sticky]").each(function() {
            var id = $(this).attr("data-sticky");

            if ($(document).scrollTop() > $(this).offset().top) {
                if (stickyId != id) {
                    stickyId = id;
                    $("#" + stickyId).show();
                }
            }
            else {
                if (stickyId == id) {
                    $("#" + stickyId).hide();
                    stickyId = "";
                }
            }
        });
    });

    $(".sticky .up").click(function() {
        $("html, body").animate({scrollTop: '0'}, 'fast');
    });
}

function submitSitemapHandler() {
    $(".submit").click(function() {
        var td = $(this).parent();
        td.html("<img src=\"" + path + "resources/images/load32.gif\" alt=\"Loading\" width=\"16px\">");

        $.get(window.location + "&sitemap=" + $(this).attr('data-id') + "&sec=" + $(this).attr('data-sec'), function(data) {
            td.html("<img src=\"" + path + "resources/images/check32.png\" alt=\"Submitted\" width=\"16px\">");
        });
    });
}

function loadWebsiteSwitcher() {
    var dropDownEnabled = false;

    $(".select").mousedown(function(e) {
        e.preventDefault();
    }).click(function() {
        if (dropDownEnabled) {
            dropDownEnabled = !dropDownEnabled;

            $(this).find(".dropdown").stop().slideUp('fast');
        }
        else {
            dropDownEnabled = !dropDownEnabled;

            $(this).find(".dropdown").stop().slideDown('fast');
        }
    });
}

function hideErrors() {
    setTimeout(function() {
        $(".error").fadeOut();
    }, 6000);
}
