$(function() {
    $(".switch, .toggle").each(function() {
        if ($(this).hasClass('setting')) return;

        var input = $(this).find("input[type=hidden]");

        if (input.size() > 0) {
            if (input.val() == "On") {
                $(this).addClass("on");
            }
        }
    });

    $(".switch, .toggle").click(function() {
        if ($(this).hasClass('setting')) return;

        var input = $(this).find("input[type=hidden]");

        if (input.val() == "On") {
            input.val("Off");
            $(this).removeClass("on");
        }
        else {
            input.val("On");
            $(this).addClass("on");
        }
    });

    $("label[data-switch]").click(function() {
        var toggleId = $(this).attr('data-switch');
        var toggle = $("#" + toggleId);
        var input = toggle.find('input[type=hidden]');

        if (input.val() == "On") {
            input.val("Off");
            toggle.removeClass("on");
        }
        else {
            input.val("On");
            toggle.addClass("on");
        }
    });

    $(".controls--user").click(function() {
        var uc = $('.user-control');
        uc.toggleClass('hidden');
    });

    $(".time").mouseover(function() {
        var span = $(this).find("span");

        if (span.find(".tooltip").size() == 0) {
            var d = new Date(parseInt(span.attr("data-time")) * 1000);
            var dstr = d.toLocaleDateString();
            var tstr = d.toLocaleTimeString();

            span.append("<div class=\"tooltip\">" + dstr + " " + tstr + "</div>");
        }
    }).mouseout(function() {
        var span = $(this).find("span");

        if (span.find(".tooltip").size() > 0) {
            span.find(".tooltip").remove();
        }
    });

    if (typeof toolsEditor !== "undefined") {
        toolEditor();

        $(".saveButton").click(function() {
            if ($(this).hasClass("disabled")) return;

            $(this).addClass("disabled").html("Saving...");
            $("form input[name=tools]").val(JSON.stringify(tools));
            $("form input[name=categories]").val(JSON.stringify(categories));
            $(".toolsForm").submit();
        });
    }

    $(".raw").click(function() {
        if ($(this).html() == "Raw") {
            $(this).html("Editor");
            $(this).parent().parent().find(".translate").hide();
            $(this).parent().parent().find(".code-editor").removeClass("hidden");
        }
        else {
            $(this).html("Raw");
            $(this).parent().parent().find(".translate").show();
            $(this).parent().parent().find(".code-editor").addClass("hidden");
        }
    });

    $("input.select-all").focus(function() { $(this).select(); } );

    if (typeof checkLiveChat !== "undefined") {
        $.get("https://baileyherbert.com/api/seostudio/support/live/available", function(data) {
            if (data.available) {
                $(".livechat").removeClass('hidden');
            }
        }, 'json');
    }

    $(".envatoSigninButton").click(function() {
        var re = window.location.href;
        re = re.substring(0, re.indexOf("admin"));
        re = re + "admin/envato.php";

        window.location = "https://api.getseostudio.com/v1/authorization?method=connect&redirect_uri=" + encodeURIComponent(re);
    });

    if ($(".pvdetails").size() > 0) {
        $(".pvdetails").html(window.location.href);
    }
});

function toolEditor() {
    $(".editor").html("");
    var accepted = false;
    var dragging = null;

    $.each(categories, function(catIndex, category) {
        var toolList = tools[category];

        var tileId = 0;
        var blank = 0;

        // this is truly a mess
        // i'm very sorry >_<

        var r = "<div class='category' data-pos='" + catIndex + "'><div class='title'>";
        r += "<input type='text' value='" + category.replace(/'/g, "\\'") + "'><div class='control'>";
        r += "<a class='up'><i class='material-icons'>keyboard_arrow_up</i></a>";
        r += "<a class='down'><i class='material-icons'>keyboard_arrow_down</i></a>";
        r += "<a class='delete'><i class='material-icons'>delete_forever</i></a>";
        r += "</div></div><div class='tiles'>";

        var num = 0;
        $.each(toolList, function(i, t) {
            tileId++;
            num++;

            if (t !== 0 && typeof t !== "undefined") {
                var id = t[0];
                var icon = t[1];
                var name = t[2];

                r += "<div class='tile' data-cat='" + category.replace(/'/g, "\\'") + "' data-tileid='" + tileId + "' data-pos='" + i + "'>";
                r += "<div class='tool-item' data-tool='" + id + "'><img src='../resources/default-icons/" + icon + ".png'>";
                r += "<span>" + name + "</span>";
                r += "</div></div>";
            }
            else {
                r += "<div class='tile' data-cat='" + category.replace(/'/g, "\\'") + "' data-tileid='" + tileId + "' data-pos='" + i + "'></div>";
                blank++;
            }
        });

        var extra = 6;
        for (x = 1; x <= extra; x++) {
            tileId++;
            r += "<div class='tile' data-cat='" + category.replace(/'/g, "\\'") + "' data-tileid='" + tileId + "'></div>";
        }

        $(".editor").append(r);
    });

    $(".editor").append("</div></div><div class='new-section'><a class='btn'>Add another section</a></div>");

    $(".tool-item").draggable({
        start: function(event, ui) {
            $(this).parent().addClass("active");
            dragging = $(this);
        },
        stop: function(event, ui) {
            $(this).parent().removeClass("active")

            if (!accepted) {
                // unsuccessful placement, revert back
                $(this).css({
                    top: 'auto',
                    left: 'auto',
                    right: 'auto',
                    bottom: 'auto'
                });
            }
        }
    });
    $(".category .tile").droppable({
        hoverClass: "hover",
        drop: function(event, ui) {
            var index = $(this).attr("data-tileid") - 1;
            var cat = $(this).attr("data-cat");

            if (dragging.parent().attr("data-tileid") !== "") {
                var dindex = dragging.parent().attr("data-tileid") - 1;
                var dcat = dragging.parent().attr("data-cat");
                var me = tools[dcat][dindex].slice();

                if (typeof tools[cat][index] !== "undefined" && tools[cat][index] !== 0) {
                    var you = tools[cat][index].slice();

                    tools[cat][index] = me;
                    tools[dcat][dindex] = you;
                    accepted = true;

                    toolEditor();
                }
                else {
                    tools[cat][index] = me;
                    tools[dcat][dindex] = 0;
                    accepted = true;

                    toolEditor();
                }
            }
            else {
                var tid = dragging.parent().attr("data-m-toolid");
                var tname = dragging.parent().attr("data-m-toolname");
                var ticon = dragging.parent().attr("data-m-toolicon");

                tools[cat][index] = [tid, ticon, tname];
                accepted = true;
                toolEditor();

                dragging.parent().remove();
            }
        }
    });

    $(".title .delete").click(function() {
        var id = parseInt($(this).parent().parent().parent().attr("data-pos"));
        var cat = categories[id];
        var isEmpty = true;

        $.each(tools[cat], function(i, v) {
            if (v !== 0 && typeof v !== "undefined") {
                isEmpty = false;
                console.log(v);
            }
        });

        if (!isEmpty) {
            alert("You cannot delete this section because it is not empty!\nPlease move all tools to other sections before deleting.");
        }
        else {
            delete tools[cat];
            categories.splice(id, 1);

            toolEditor();
        }
    });

    $(".title .up").click(function() {
        var id = parseInt($(this).parent().parent().parent().attr("data-pos"));
        var cat = categories[id];

        if (id > 0) {
            var swapWith = categories[id - 1];
            categories[id - 1] = cat;
            categories[id] = swapWith;

            toolEditor();
        }
    });

    $(".title .down").click(function() {
        var id = parseInt($(this).parent().parent().parent().attr("data-pos"));
        var cat = categories[id];

        if (id < (categories.length - 1)) {
            var swapWith = categories[id + 1];

            if (typeof swapWith !== "undefined") {
                categories[id + 1] = cat;
                categories[id] = swapWith;

                toolEditor();
            }
            else {
                console.log('no')
            }
        }
    });

    $(".new-section a").click(function() {
        categories.push("Untitled #" + (categories.length + 1));
        tools["Untitled #" + (categories.length)] = [];

        toolEditor();
    });

    $(".title input").change(function() {
        var newName = $(this).val();
        var id = parseInt($(this).parent().parent().attr("data-pos"));
        var oldName = categories[id];

        if (tools[newName]) {
            newName += "$!" + Math.floor(Math.random() * 999999) + 100000;
            alert('There cannot be more than one section with the same name.');
        }

        categories[id] = newName;

        var toolsDataClone = tools[oldName].slice();
        delete tools[oldName];
        tools[newName] = toolsDataClone;

        toolEditor();
    });
}
