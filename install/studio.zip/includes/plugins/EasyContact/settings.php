<div class="panel">
    <h3>Translate contact page</h3>
    <a class="btn" href="translate.php?name=plugin.contact">Edit translations</a>
</div>

<form action="" method="post">
<div class="panel settings">
    <h3>Contact options</h3>

    <div class="setting">
        <table>
            <tr>
                <td width="50%">
                    Block messages that look like spam
                </td>
                <td>
                    <div class="toggle">
                        <input type="hidden" name="contact-block-spam" value="<?php echo $this->getopt('contact-block-spam'); ?>">
                        <div class="handle"></div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
    <div class="setting">
        <table>
            <tr>
                <td width="50%">
                    Temporarily block users who send too many emails, too quickly
                </td>
                <td>
                    <div class="toggle">
                        <input type="hidden" name="contact-block-speed" value="<?php echo $this->getopt('contact-block-speed'); ?>">
                        <div class="handle"></div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>

<div class="panel settings">
    <h3>Email options</h3>

    <div class="setting">
        <table>
            <tr>
                <td width="50%">
                    Send contact emails to
                </td>
                <td>
                    <input type="text" name="contact-email-sendto" value="<?php echo $this->getopt('contact-email-sendto'); ?>">
                </td>
            </tr>
        </table>
    </div>
    <div class="setting">
        <table>
            <tr>
                <td width="50%">
                    Send contact emails from
                </td>
                <td>
                    <input type="text" name="contact-email-sendfrom" value="<?php echo $this->getopt('contact-email-sendfrom'); ?>">
                </td>
            </tr>
        </table>
    </div>
</div>

<div class="panel">
    <input type="submit" class="btn blue" value="Save changes">
</div>
</form>
