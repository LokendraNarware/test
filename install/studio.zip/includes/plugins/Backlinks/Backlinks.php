<?php

use Studio\Extend\Plugin;

class Backlinks extends Plugin
{
    const NAME          =   "Backlink Tool Pack";
    const DESCRIPTION   =   "Adds tools to find the newest, highest quality, and poorest backlinks for a site, using SEO Profiler. Do not use or sell this information to compete with SEO Profiler.";
    const AUTHOR        =   "Bailey Herbert";
    const VERSION       =   "1.0";

    var $settings = true;

    function start() {
        $this->hook("admin_head", "showWarning");
    }

    function showWarning() {
        if ($this->getopt("seoprofiler-email") == "") {
            echo "<div class='warning'>Backlink tools will not work until you <a href='plugins.php'>configure the Backlink Tool Pack</a>.</div>";
        }
    }

    function settings() {
        if (isset($_POST['seoprofiler-email'])) {
            $this->setopt("seoprofiler-email", $_POST['seoprofiler-email']);
            $this->setopt("seoprofiler-password", $_POST['seoprofiler-password']);

            $profiler = new \SEO\Services\SEOprofiler($_POST['seoprofiler-email'], $_POST['seoprofiler-password']);

            try {
                $profiler->authenticate();
                echo "<div class='success'>Account credentials saved!</div>";
            }
            catch (\Exception $e) {
                if ($e->getCode() == 1) echo "<div class='error'>Connection to backlink service failed.</div>";
                elseif ($e->getCode() == 2) echo "<div class='error'>Authentication failed for backlink service.</div>";
                elseif ($e->getCode() == 6) echo "<div class='error'>Failed to write file to /libraries/SEO/Data/</div>";
                else echo "<div class='error'>Unknown error occurred when trying to test new login credentials.</div></div>";
            }

        }
        require $this->pluginDir . "/settings.php";
    }

    function onEnable() {
        $toolsDir = $this->baseDir . "/libraries/Studio/Tools";
        $myTools = $this->pluginDir . "/tools/";

        if (file_put_contents("$toolsDir/HighQualityBacklinks.php", file_get_contents("$myTools/HighQualityBacklinks.php")) == false) return $this->showError("Can't create file in $toolsdir");
        if (file_put_contents("$toolsDir/NewBacklinks.php", file_get_contents("$myTools/NewBacklinks.php")) == false) return $this->showError("Can't create file in $toolsdir");
        if (file_put_contents("$toolsDir/PoorBacklinks.php", file_get_contents("$myTools/PoorBacklinks.php")) == false) return $this->showError("Can't create file in $toolsdir");
        if (file_put_contents("$toolsDir/TopReferrers.php", file_get_contents("$myTools/TopReferrers.php")) == false) return $this->showError("Can't create file in $toolsdir");

        $this->setopt("seoprofiler-email", "");
        $this->setopt("seoprofiler-password", "");

        return true;
    }

    function onDisable() {
        $toolsDir = $this->baseDir . "/libraries/Studio/Tools";
        $files = ["HighQualityBacklinks.php", "NewBacklinks.php", "PoorBacklinks.php", "TopReferrers.php"];

        foreach ($files as $file) {
            if (file_exists($toolsDir .'/'. $file)) {
                if (unlink($toolsDir.'/'.$file) === false) return $this->showError("Failed to remove file $toolsDir/$file");
            }
        }

        $this->setopt("seoprofiler-email", "");
        $this->setopt("seoprofiler-password", "");
    }

}
