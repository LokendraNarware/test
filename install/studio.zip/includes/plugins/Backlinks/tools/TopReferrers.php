<?php

namespace Studio\Tools;

use SEO\Services\Alexa;
use SEO\Services\SEOprofiler;
use Exception;

class TopReferrers extends Tool
{
    var $name = "Top Referrers";
    var $id = "top-referrers";
    var $icon = "top-referrers";
    var $template = "top-referrers.html";

    public function run() {
        global $studio;
        @ini_set('max_execution_time', 120);

        $alexa = new Alexa($this->url);
        $this->data = $alexa->topReferrers();

        if (!is_array($this->data)) throw new Exception(rt("No referring sites found."));

        $profiler = new SEOprofiler($studio->getopt("seoprofiler-email"), $studio->getopt("seoprofiler-password"));
        try {
            $profiler->authenticate();
        }
        catch (Exception $e) {
            if ($e->getCode() == 1) throw new Exception(rt("Connection to backlink service failed."));
            if ($e->getCode() == 2) throw new Exception(rt("Authentication failed for backlink service."));
            if ($e->getCode() == 6) throw new Exception(rt("Failed to write file to /libraries/SEO/Data/"));
            if ($e->getCode() == 7) throw new \Exception(rt("This site is too big to track backlinks, sorry."));
            throw new Exception(rt("Unknown error."));
        }

        foreach ($this->data as $i => $row) {
            $row['domain'] = trim(str_replace("&nbsp;&nbsp", "", $row['domain']));

            try {
                $b = $profiler->getBacklinks(new \SEO\Helper\Url(trim($row['domain'])), 10, 12);
                $this->data[$i]['influence'] = $b['stats']['link influence score (lis)'];
                $this->data[$i]['backlinks'] = $b['stats']['active links'];
            }
            catch (Exception $e) {
                $this->data[$i]['influence'] = "?";
                $this->data[$i]['backlinks'] = "?";
            }
        }
    }

    public function output() {
        $html = $this->getTemplate();

        $dataHTML = "";
        foreach ($this->data as $i => $row) {
            $odd = (($i % 2 == 0) ? "" : "odd");

            $dataHTML .= "<tr class=\"$odd\">
                <td>{$row['domain']}</td>
                <td class=\"center\">{$row['percent']}%</td>
                <td class=\"center\">{$row['influence']}</td>
                <td class=\"center\">{$row['backlinks']}</td>
            </tr>";
        }

        $html = str_replace("[[DATA]]", $dataHTML, $html);
        echo $html;
    }
}

?>
