<?php

namespace Studio\Tools;

class HighQualityBacklinks extends Tool
{
    var $name = "High Quality Backlinks";
    var $id = "high-quality-backlinks";
    var $icon = "high-quality-backlinks";
    var $template = "backlinks.html";

    public function run() {
        global $studio;

        $profiler = new \SEO\Services\SEOprofiler($studio->getopt("seoprofiler-email"), $studio->getopt("seoprofiler-password"));

        try {
            $profiler->authenticate();
        }
        catch (\Exception $e) {
            if ($e->getCode() == 1) throw new \Exception(rt("Connection to backlink service failed."));
            if ($e->getCode() == 2) throw new \Exception(rt("Authentication failed for backlink service."));
            if ($e->getCode() == 6) throw new \Exception(rt("Failed to write file to /libraries/SEO/Data/"));
            throw new \Exception(rt("Unknown error."));
        }

        try {
            $this->data = $profiler->getBacklinks($this->url, 100, 13);
        }
        catch (\Exception $e) {
            if ($e->getCode() == 1) throw new \Exception(rt("Backlink service not authenticated."));
            if ($e->getCode() == 2) throw new \Exception(rt("Connection to backlink service failed."));
            if ($e->getCode() == 3) throw new \Exception($e->getMessage());
            if ($e->getCode() == 7) throw new \Exception(rt("This site is too big to track backlinks, sorry."));
            throw new \Exception(rt("Unknown error."));
        }
    }

    public function output() {
        global $studio;

        $html = $this->getTemplate();

        # Statistics

        foreach ($this->data['stats'] as $stat => $value) {
            $ustat = strtoupper($stat);
            $html = str_replace("[[STAT:{$ustat}]]", $value, $html);
        }

        # Backlinks

        $snippet = "";

        foreach ($this->data['links'] as $i => $link) {
            $influence = $link['influence'];
            $pageTitle = $studio->attr(strip_tags($link['page title']));
            $pageLink = $link['page link'];
            $anchorText = $studio->attr(strip_tags($link['anchor text']));
            $anchorLink = $link['anchor link'];
            $discovered = $link['date added'];

            $shortPageLink = $pageLink;
            $shortAnchorLink = $anchorLink;
            $shortPageTitle = $pageTitle;
            $shortAnchorText = $anchorText;

            if (strlen($shortPageLink) > 70) $shortPageLink = substr($shortPageLink, 0, 68) . "...";
            if (strlen($shortAnchorLink) > 70) $shortAnchorLink = substr($shortAnchorLink, 0, 68) . "...";
            if (strlen($shortPageTitle) > 70) $shortPageTitle = substr($shortPageTitle, 0, 68) . "...";
            if (strlen($shortAnchorText) > 70) $shortAnchorText = substr($shortAnchorText, 0, 68) . "...";

            $nofollow = "";
            $noindex = "";

            if (isset($link['nofollow'])) $nofollow = "<span class=\"red-label\">" . rt("nofollow") . "</span>";
            if (isset($link['noindex'])) $noindex = "<span class=\"red-label\">" . rt("noindex") . "</span>";

            $odd = (($i % 2) == 0 ? "" : "odd");
            $snippet .= "<tr class=\"$odd\">
                <td class=\"center\">{$influence}</td>
                <td>
                    <strong title=\"{$pageTitle}\">{$shortPageTitle}</strong><br />
                    <a href=\"{$pageLink}\">{$shortPageLink}</a>
                </td>
                <td>
                    <strong title=\"{$anchorText}\">{$shortAnchorText}</strong><br />
                    <a href=\"{$anchorLink}\">{$shortAnchorLink}</a>
                    <div>
                        {$nofollow} {$noindex}
                    </div>
                </td>
                <td class=\"center\" class=\"center\">{$discovered}</td>
            </tr>";
        }

        $html = str_replace("[[BACKLINKS]]", $snippet, $html);
        $html = str_replace("[[TITLE]]", rt("Top Backlinks"), $html);

        echo $html;
    }
}
