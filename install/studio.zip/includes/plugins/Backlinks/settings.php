<div class="panel">
    <h3>SEO Profiler settings</h3>
    <p>Please enter the email address and password for your <a href="http://seoprofiler.com">seoprofiler</a> account. You only need a free account for it to work. <strong>Warning</strong> the password is stored in the database in plain-text so don't use something secure!</p>

    <form action="" method="post" style="margin: 20px 0 0;">
        <p><strong>Email address</strong></p>
        <input type="text" name="seoprofiler-email" class="fancy" placeholder="Email" value="<?php echo $this->getopt('seoprofiler-email'); ?>">

        <p><strong>Password</strong></p>
        <input type="password" name="seoprofiler-password" class="fancy" placeholder="Password" value="<?php echo $this->getopt('seoprofiler-password'); ?>">

        <input type="submit" class="btn blue" value="Save">
    </form>
</div>
