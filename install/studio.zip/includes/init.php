<?php

error_reporting(E_ALL);
ini_set('display_errors', 'Off');

ob_start();
session_start();

@set_time_limit(0);

require_once dirname(dirname(__FILE__)) . "/libraries/autoload.php";

$studio = new Studio\Base\Studio();
$plugins = $studio->getPluginManager();

if (!isset($continueWithoutSQL) && $studio->sql !== null) {

    $reportErrors = ($studio->getopt('send-errors') == 'On');

    function studioErrorHandler($code, $message, $file, $line) {
        global $studio, $reportErrors;

        $message = str_replace("\t", " ", $message);
        $message = str_replace("\r\n", "\n", $message);
        $message = str_replace("\n", " ", $message);

        $types = array(
            E_ERROR => "FATAL",
            E_PARSE => "PARSE",
            E_WARNING => "WARNING",
            E_NOTICE => "NOTICE",
            E_STRICT => "STRICT",
            E_DEPRECATED => "DEPRECATED",
            E_USER_ERROR => "USER_ERROR",
            E_USER_WARNING => "USER_WARNING",
            E_USER_NOTICE => "USER_NOTICE"
        );
        $type = $types[$code];

        $shortfile = str_ireplace(dirname(dirname(__FILE__)), "", $file);

        $ray = "0";
        if ($reportErrors) $ray = $studio->reportError($type, $message, $shortfile, $line);

        $errorLogPath = dirname(dirname(__FILE__)) . "/.studio.log";
        if (is_writable(dirname(dirname(__FILE__)))) {
            @date_default_timezone_set("UTC");
            $hash = md5($type . $message . $shortfile . $line);

            $errorLine = "$hash\t$type\t$message\t$shortfile\t$line\t" . date(DATE_ATOM) . "\t$ray" . PHP_EOL;

            $existing = (file_exists($errorLogPath) ? file_get_contents($errorLogPath) : "");
            $lines = substr_count($existing, "\n");

            if (stripos($existing, "$hash\t") === false) {
                if ($lines >= 100) {
                    $endFirstLine = strpos($existing, "\n");
                    $existing = substr($existing, $endFirstLine + 1);
                }

                @file_put_contents($errorLogPath, $existing . $errorLine);
            }
        }

        $data = file_get_contents(dirname(dirname(__FILE__)) . "/resources/bin/error.html");
        $data = str_replace("<!-- ray -->", $ray, $data);

        if ($studio->config['errors']['show']) {
            $data = str_replace("<!-- error -->", $message, $data);
            $data = str_replace("<!-- file -->", $shortfile . " on line $line", $data);
            echo $data;
            die;
        }

        if ($type == "FATAL" || $studio->config['errors']['show']) {
            echo $data;
            die;
        }
    }

    function studioShutdown() {
        $error = error_get_last();
        if ($error['type'] == E_ERROR) {
            studioErrorHandler(E_ERROR, $error['message'], $error['file'], $error['line']);
        }
    }

    set_error_handler('studioErrorHandler');
    register_shutdown_function('studioShutdown');

    $account = new Studio\Base\Account($studio);
    $language = new Studio\Base\Language(dirname(dirname(__FILE__)) . "/resources/languages");
    $page = new Studio\Display\Page($studio);
    $site = $account->getCurrentWebsite();

    $api = new API\API($studio->getopt("api.secretkey"));
}

# Define variables for the API

$apiCertificatePath = dirname(dirname(__FILE__)) . "/resources/certificates/baileyherbert.DSTRootCAX3.crt";
$seohubCertificatePath = dirname(dirname(__FILE__)) . "/resources/certificates/baileyherbert.DSTRootCAX3.crt";

/**
 * Returns a translation, filling in the specified variable values.
 * @param String $p The input string to translate.
 * @param mixed $a  Value to replace the {$1} variable.
 * @param mixed $b  Value to replace the {$2} variable.
 * @param mixed $c  Value to replace the {$3} variable.
 * @param mixed $d  Value to replace the {$4} variable.
 * @return String The new, translated phrase.
 */
function rt($p, $a = null, $b = null, $c = null, $d = null) {
    global $language;
    $t = $language->translate($p);

    if ($a !== null) $t = str_replace('{$1}', $a, $t);
    if ($b !== null) $t = str_replace('{$2}', $b, $t);
    if ($c !== null) $t = str_replace('{$3}', $c, $t);
    if ($d !== null) $t = str_replace('{$4}', $d, $t);

    return $t;
}

function et($p, $a = null, $b = null, $c = null, $d = null) {
    echo rt($p, $a, $b, $c, $d);
}

function pt($p, $a = null, $b = null, $c = null, $d = null) {
    et($p, $a, $b, $c, $d);
}


# Call the studio_loaded plugin hook

$plugins->start();
$plugins->call("studio_loaded");
