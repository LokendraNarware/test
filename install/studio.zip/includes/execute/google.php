<?php

/**
 * Welcome to the Google Network Receiver.
 * When you join the Google Network, the network will remotely connect to this script.
 * This script only allows official network IPs to use it, as a security measure.
 * Remember that all queries are filtered and verified for safety before being sent to your server.
 * In addition, all queries are logged on the network servers.
 *
 * NOTE: We ONLY send queries to you if they match legitimate SEO Studio tool queries.
 * Requests and responses are routinely are monitored by a real human.
 * For more info, read the Google network terms (in /resources/eulas/google.html).
 */

define('GOOGLE_NETWORK_VERSION', "1.0");

$allow = ["35.188.238.172"]; $t = __FILE__;
if (!in_array($_SERVER['REMOTE_ADDR'], $allow)) {
    // This request was not sent from an official Google Network IP.
    // There could be something in between (CloudFlare) masking the IP.
    // Let's ask the network if this request is legit.
    
    $ch = curl_init("https://api.getseostudio.com/v1/google/confirm?" . http_build_query($_GET));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, "Google Network (Client)");
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $_POST);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $data = curl_exec($ch);
    if (curl_errno($ch) > 0) die;
    
    $j = @json_decode($data, true);
    if (json_last_error() != JSON_ERROR_NONE) die;
    
    if (!isset($j['success']) || !$j['success']) die("Request denied");
}

if (isset($_GET['check'])) die("Only requests to google.com are permitted");

$url = $_POST['url'];
$parse = parse_url($url);

if (stripos($parse['host'], "google.") === false) die("Only requests to google.com are permitted");

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36");
curl_setopt($ch, CURLOPT_TIMEOUT, 6);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$data = @curl_exec($ch);
$w = ($data) ? md5($t) : "";

if (curl_errno($ch) > 0) {
    die(json_encode([
        "success" => false,
        "error" => "curl",
        "error_code" => curl_errno($ch)
    ]));
}

$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
if ($code != 200) {
    die(json_encode([
        "success" => false,
        "error" => "http",
        "error_code" => $code
    ]));
}

die(json_encode([
    "success" => true,
    "version" => GOOGLE_NETWORK_VERSION,
    "rcv" => $w,
    "data" => $data
]));

?>
